-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 19, 2024 at 06:31 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_indah`
--

-- --------------------------------------------------------

--
-- Table structure for table `bayar`
--

DROP TABLE IF EXISTS `bayar`;
CREATE TABLE IF NOT EXISTS `bayar` (
  `id_bayar` int NOT NULL AUTO_INCREMENT,
  `id_kembali` int DEFAULT NULL,
  `tgl_bayar` date DEFAULT NULL,
  `total_bayar` decimal(10,2) DEFAULT NULL,
  `status` enum('lunas','belum lunas') COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_bayar`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bayar`
--

INSERT INTO `bayar` (`id_bayar`, `id_kembali`, `tgl_bayar`, `total_bayar`, `status`) VALUES
(1, 1, '2024-10-19', '150000.00', 'lunas'),
(2, 2, '2024-10-19', '2000000.00', 'lunas');

-- --------------------------------------------------------

--
-- Table structure for table `kembali`
--

DROP TABLE IF EXISTS `kembali`;
CREATE TABLE IF NOT EXISTS `kembali` (
  `id_kembali` int NOT NULL AUTO_INCREMENT,
  `id_transaksi` int DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `kondisi_mobil` text COLLATE utf8mb4_general_ci,
  `denda` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_kembali`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kembali`
--

INSERT INTO `kembali` (`id_kembali`, `id_transaksi`, `tgl_kembali`, `kondisi_mobil`, `denda`) VALUES
(1, 1, '2024-10-19', 'spion rusak', '150000.00'),
(2, 2, '2024-10-19', 'ringsek ', '2000000.00'),
(3, 3, '2024-10-19', 'bagus', '10000.00');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
CREATE TABLE IF NOT EXISTS `member` (
  `nik` int NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `jk` enum('l','p') COLLATE utf8mb4_general_ci NOT NULL,
  `telp` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_general_ci,
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`nik`, `nama`, `jk`, `telp`, `alamat`, `username`, `password`) VALUES
(11011, 'Toni Widiyanto', 'l', '0816469867', 'Tegalrandu', 'toni', '81dc9bdb52d04dc20036dbd8313ed055'),
(11287, 'Aspasya Salsabila', 'p', '088376263829', 'Pakis', 'pasya', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

DROP TABLE IF EXISTS `mobil`;
CREATE TABLE IF NOT EXISTS `mobil` (
  `nopol` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `brand` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tahun` year DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `foto` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('tersedia','tidak') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`nopol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`nopol`, `brand`, `type`, `tahun`, `harga`, `foto`, `status`) VALUES
('AA3636BU', 'Hyundai', 'Sedan', 2020, '200000.00', 'sedanmobil.jpg', 'tersedia'),
('AA5698PO', 'Daihatsu', 'Pick Up', 2018, '100000.00', 'sedanmobil.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_transaksi` int NOT NULL AUTO_INCREMENT,
  `nik` int DEFAULT NULL,
  `nopol` varchar(10) DEFAULT NULL,
  `tgl_booking` date NOT NULL,
  `tgl_ambil` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `supir` tinyint(1) DEFAULT '0',
  `total` decimal(10,2) DEFAULT NULL,
  `downpayment` decimal(10,2) NOT NULL,
  `kekurangan` decimal(10,2) DEFAULT NULL,
  `status` enum('booking','approve','ambil','kembali') NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `nik` (`nik`),
  KEY `nopol` (`nopol`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nik`, `nopol`, `tgl_booking`, `tgl_ambil`, `tgl_kembali`, `supir`, `total`, `downpayment`, `kekurangan`, `status`) VALUES
(1, 11011, 'AA3636BU', '2024-10-19', '2024-10-20', '2025-01-25', 1, '2000000.00', '1000000.00', '1000000.00', 'kembali'),
(2, 11287, 'AA5698PO', '2024-10-19', '2024-11-01', '2024-11-07', 1, '50000.00', '25000.00', '25000.00', 'kembali'),
(3, 11011, 'AA5698PO', '2024-10-19', '2024-11-01', '2024-11-02', 0, '100000.00', '50000.00', '50000.00', 'kembali');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','petugas') NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `role`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'petugas', '81dc9bdb52d04dc20036dbd8313ed055', 'petugas');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
