<?php
    include "koneksi.php"; // Koneksi ke database
    session_start(); // Memulai session
    
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['nik'])) {
        header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
        exit();
    }
  
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Rentall Digital</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="img\.png"> 
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
    .star-rating {
        font-size: 2rem; /* Ukuran bintang lebih besar */
        direction: rtl;
        display: inline-flex;
        justify-content: flex-end;
        cursor: pointer;
    }

    .star {
        color: #ccc;
        padding: 0 5px;
    }

    .star.selected {
        color: #f39c12;
    }

</style>

    <style>
    
    .btn-outline-primary:hover {
        background-color: #5CB377; 
        color: white; 
    }

    .btn-outline-primary {
    --bs-btn-color: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #FFFF;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 21, 163, 98;
    --bs-btn-active-color: #FFFF;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #5cb377;
    --bs-btn-disabled-bg: transparent;
    --bs-gradient: none;
    }

	.btn-info {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 77, 130, 199;
    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #5cb377;
    --bs-btn-disabled-border-color: #5cb377;
}

.btn-primary {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5b99ea ;
    --bs-btn-border-color: #5b99ea ;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5b99ea;
    --bs-btn-hover-border-color: #5b99ea;
    --bs-btn-focus-shadow-rgb: 18, 139, 83;
    --bs-btn-active-color: #ffff;
    --bs-btn-active-bg: #44b581;
    --bs-btn-active-border-color: #2cac72;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #15a362;
    --bs-btn-disabled-border-color: #15a362;
}
</style>



</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
            <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            
		            <div class="app-utilities col-auto">
			            
			            <div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img src="assets/images/user.png" alt="user profile"></a>
				            <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="../logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown-->  
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel sidepanel-hidden"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="index.php"><span class="logo-text">Rentall</span></a>
	
		        </div><!--//app-branding-->  
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="index.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Beranda</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="mobil.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-car-front" viewBox="0 0 16 16">
  <path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0m10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0M6 8a1 1 0 0 0 0 2h4a1 1 0 1 0 0-2zM4.862 4.276 3.906 6.19a.51.51 0 0 0 .497.731c.91-.073 2.35-.17 3.597-.17s2.688.097 3.597.17a.51.51 0 0 0 .497-.731l-.956-1.913A.5.5 0 0 0 10.691 4H5.309a.5.5 0 0 0-.447.276"/>
  <path d="M2.52 3.515A2.5 2.5 0 0 1 4.82 2h6.362c1 0 1.904.596 2.298 1.515l.792 1.848c.075.175.21.319.38.404.5.25.855.715.965 1.262l.335 1.679q.05.242.049.49v.413c0 .814-.39 1.543-1 1.997V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.338c-1.292.048-2.745.088-4 .088s-2.708-.04-4-.088V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.892c-.61-.454-1-1.183-1-1.997v-.413a2.5 2.5 0 0 1 .049-.49l.335-1.68c.11-.546.465-1.012.964-1.261a.8.8 0 0 0 .381-.404l.792-1.848ZM4.82 3a1.5 1.5 0 0 0-1.379.91l-.792 1.847a1.8 1.8 0 0 1-.853.904.8.8 0 0 0-.43.564L1.03 8.904a1.5 1.5 0 0 0-.03.294v.413c0 .796.62 1.448 1.408 1.484 1.555.07 3.786.155 5.592.155s4.037-.084 5.592-.155A1.48 1.48 0 0 0 15 9.611v-.413q0-.148-.03-.294l-.335-1.68a.8.8 0 0 0-.43-.563 1.8 1.8 0 0 1-.853-.904l-.792-1.848A1.5 1.5 0 0 0 11.18 3z"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Daftar Mobil</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

                        <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="koleksi.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-columns-gap" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M6 1H1v3h5V1zM1 0a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1H1zm14 12h-5v3h5v-3zm-5-1a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-5zM6 8H1v7h5V8zM1 7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1H1zm14-6h-5v7h5V1zm-5-1a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1h-5z"></path>
	</svg>
						         </span>
		                         <span class="nav-link-text">Koleksi</span>
					        </a><!--//nav-link-->
					    </li>
					    
				    </ul><!--//app-menu-->
			    </nav><!--//app-nav-->
			    
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->
    
    <div class="app-wrapper">
	
		    
    <div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
    <h1 class="app-page-title">Status Sewa Mobil</h1>
    <div class="app-card app-card-transactions-table shadow-sm mb-5">
        <div class="app-card-body">
            <div class="table-responsive">
            <table class="table mb-0 text-left">
    <thead>
        <tr>
            <th class="cell">Order</th>
            <th class="cell">Nama Pemohon</th>
            <th class="cell">Mobil</th>
            <th class="cell">Tanggal Booking</th>
            <th class="cell">Tanggal Ambil</th>
            <th class="cell">Status</th>
            <th class="cell"></th>
        </tr>
    </thead>
    <tbody>
        <!-- PHP code to fetch and display rental status -->
        <!-- PHP code to fetch and display rental status -->
<?php
$nik = $_SESSION['nik']; // Ambil NIK dari session

// Query untuk mengambil data transaksi dan status pelunasan
$query = "
    SELECT t.*, m.nama, b.status AS status_pelunasan 
    FROM transaksi t
    JOIN member m ON t.nik = m.nik
    LEFT JOIN bayar b ON t.id_transaksi = b.id_kembali
    WHERE t.nik = '$nik'
";
$result = mysqli_query($koneksi, $query);

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td class='cell'>#" . $row['id_transaksi'] . "</td>";
    echo "<td class='cell'>" . $row['nama'] . "</td>";
    echo "<td class='cell'>" . $row['nopol'] . "</td>";
    echo "<td class='cell'>" . date('d M Y', strtotime($row['tgl_booking'])) . "</td>";
    echo "<td class='cell'>" . date('d M Y', strtotime($row['tgl_ambil'])) . "</td>";

    // Menampilkan status berdasarkan status transaksi
    if ($row['status'] === 'booking') {
        echo "<td class='cell'><span class='badge bg-warning'>Booked</span></td>";
    } elseif ($row['status'] === 'approve') {
        echo "<td class='cell'><span class='badge bg-info'>Approved</span></td>";
    } elseif ($row['status'] === 'kembali') {
        // Jika status transaksi kembali, anggap selesai
        echo "<td class='cell'><span class='badge bg-success'>Selesai</span></td>";
        echo "<td class='cell'><a target='_blank' href='unduh_kwitansi.php?id=" . $row['id_transaksi'] . "' class='btn btn-warning' style='color: white'>Unduh Kwitansi</a></td>";
    } else {
        echo "<td class='cell'><span class='badge bg-secondary'>" . ucfirst($row['status']) . "</span></td>";
    }

    echo "</tr>";
}
?>

    </tbody>
</table>

            </div>
        </div>
    </div>
    <div class="alert alert-info" role="alert">
        Jika status mobil Anda "Approved", Anda dapat mengambil mobil sesuai tanggal ambil yang telah ditentukan.
    </div>
    </div>
</div>

	    </div><!--//app-content-->
	    
	    <footer class="app-footer">
		    <div class="container text-center py-3">
		         <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
            <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart" style="color: #fb866a;"></i> by <a class="app-link" href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
		       
		    </div>
	    </footer><!--//app-footer-->
	    
    </div><!--//app-wrapper-->    	
	
	
		<!-- Modal -->
<div class="modal fade" id="returnModal" tabindex="-1" aria-labelledby="returnModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="returnModalLabel">Informasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-message">
                <!-- Pesan akan ditambahkan di sini -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary" onclick="window.location.href='koleksi.php'">Kembali ke Daftar Buku</button>
            </div>
        </div>
    </div>
</div>
    <!-- Tambahkan CSS untuk bintang -->


<!-- Tambahkan JavaScript untuk mengatur klik bintang -->


 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<script>
// Tunggu sampai DOM siap
document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.star');
    const ratingInput = document.getElementById('rating');

    stars.forEach(star => {
        star.addEventListener('click', function() {
            const value = this.getAttribute('data-value');
            ratingInput.value = value;
            
            stars.forEach(s => {
                if (s.getAttribute('data-value') <= value) {
                    s.classList.add('selected');
                } else {
                    s.classList.remove('selected');
                }
            });
        });
    });
});
</script>

<script>
    function filterByGenre(genre) {
        const rows = document.querySelectorAll('#book-list .book-item');
        rows.forEach(row => {
            if (row.getAttribute('data-genre') === genre) {
                row.style.display = ''; // Tampilkan baris yang sesuai
            } else {
                row.style.display = 'none'; // Sembunyikan baris yang tidak sesuai
            }
        });
    }

    function resetFilter() {
        const rows = document.querySelectorAll('#book-list .book-item');
        rows.forEach(row => {
            row.style.display = ''; // Tampilkan semua baris
        });
    }
</script>
</body>
</html> 
