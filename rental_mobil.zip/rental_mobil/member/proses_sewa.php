<?php
session_start();
include 'koneksi.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'];
    $nopol = $_POST['nopol']; // Pastikan Anda menambahkan ini di form
    $tgl_booking = $_POST['tgl_booking'];
    $tgl_ambil = $_POST['tgl_ambil'];
    $days = (new DateTime($_POST['tgl_kembali']))->diff(new DateTime($tgl_ambil))->days; // Hitung jumlah hari
    $supir = $_POST['supir'] == '1' ? 1 : 0; // Convert to boolean

    // Fetch price per day from the database
    $pricePerDay = 0;
    $query_price = "SELECT harga FROM mobil WHERE nopol = '$nopol'";
    $result_price = mysqli_query($koneksi, $query_price);
    if ($result_price) {
        $row_price = mysqli_fetch_assoc($result_price);
        $pricePerDay = $row_price['harga'];
    }

    $total = ($pricePerDay * $days) + ($supir ? 50000 : 0); // Example driver fee
    $downpayment = $total * 0.5; // 50% downpayment
    $kekurangan = $total - $downpayment;

    // Insert into transaksi table
    $query = "INSERT INTO transaksi (nik, nopol, tgl_booking, tgl_ambil, tgl_kembali, supir, total, downpayment, kekurangan, status) 
              VALUES ('$nik', '$nopol', '$tgl_booking', '$tgl_ambil', DATE_ADD('$tgl_ambil', INTERVAL $days DAY), '$supir', '$total', '$downpayment', '$kekurangan', 'booking')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Booking berhasil!'); window.location.href='koleksi.php';</script>";
    } else {
        echo "<script>alert('Booking gagal!'); window.history.back();</script>";
    }
} else {
    echo "Tidak ada data yang diterima.";
}

mysqli_close($koneksi); // Tutup koneksi
?>
