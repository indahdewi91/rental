<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kwitansi Pembayaran</title>
    <style>
        /* CSS untuk tampilan cetak */
        @media print {
            @page {
                margin: 0; /* Hilangkan margin yang biasanya memunculkan URL di header/footer */
            }
            body {
                margin: 1cm; /* Tambahkan margin internal agar dokumen rapi */
            }

            /* Hilangkan elemen yang tidak diperlukan */
            .no-print {
                display: none;
            }
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 15px;
        }

        .kwitansi {
            border: 1px solid #ddd;
            background-color: #fff;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 90%; /* Lebar kwitansi */
            max-width: 600px; /* Ukuran maksimum untuk desktop */
            margin: auto; /* Pusatkan kwitansi */
        }

        .info {
            margin-bottom: 5px;
            padding: 5px;
            border-bottom: 1px solid #ddd;
        }

        .label {
            font-weight: bold;
            color: #555;
            display: inline-block;
            width: 200px; /* Lebar tetap untuk menyelaraskan titik dua */
            text-align: left; /* Rata kiri */
        }

        .value {
            font-weight: normal;
            color: #333;
            display: inline-block;
            width: calc(100% - 220px); /* Mengisi sisa ruang dengan mempertimbangkan lebar label */
            text-align: right; /* Rata kanan */
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-style: italic;
        }

        button {
            background-color: #4CAF50; /* Hijau */
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

    <h2>Kwitansi Pembayaran</h2>
    <div class="kwitansi">
        <?php
        include "../koneksi.php"; // Pastikan ini mengarah ke file koneksi database

        $id_transaksi = $_GET['id']; // Ambil id_transaksi dari query string

        // Query untuk mengambil data berdasarkan id_transaksi
        $query = mysqli_query($koneksi, "
            SELECT 
                t.id_transaksi, 
                m.nama AS customer, 
                c.nopol, 
                c.brand, 
                c.type, 
                t.tgl_booking,
                t.tgl_ambil,
                t.tgl_kembali,
                t.total,
                IF(b.status IS NULL, 'Belum Lunas', b.status) AS status_pelunasan,
                k.kondisi_mobil,
                k.denda
            FROM transaksi t 
            JOIN member m ON t.nik = m.nik 
            JOIN mobil c ON t.nopol = c.nopol
            LEFT JOIN kembali k ON t.id_transaksi = k.id_transaksi
            LEFT JOIN bayar b ON k.id_kembali = b.id_kembali
            WHERE t.id_transaksi = '$id_transaksi'");

        // Ambil data
        $data = mysqli_fetch_assoc($query);

        // Periksa apakah data ditemukan
        if (!$data) {
            die("Transaksi tidak ditemukan.");
        }
        ?>

        <div class="info">
            <span class="label">Nomor Transaksi:</span>
            <span class="value"><?php echo $data['id_transaksi']; ?></span>
        </div>
        <div class="info">
            <span class="label">Tanggal:</span>
            <span class="value"><?php echo date('d-m-Y'); ?></span>
        </div>
        <div class="info">
            <span class="label">Customer:</span>
            <span class="value"><?php echo isset($data['customer']) ? $data['customer'] : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Nomor Polisi:</span>
            <span class="value"><?php echo isset($data['nopol']) ? $data['nopol'] : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Merek Mobil:</span>
            <span class="value"><?php echo isset($data['brand']) ? $data['brand'] : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Tipe Mobil:</span>
            <span class="value"><?php echo isset($data['type']) ? $data['type'] : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Tanggal Booking:</span>
            <span class="value"><?php echo isset($data['tgl_booking']) ? date('d-m-Y', strtotime($data['tgl_booking'])) : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Tanggal Ambil:</span>
            <span class="value"><?php echo isset($data['tgl_ambil']) ? date('d-m-Y', strtotime($data['tgl_ambil'])) : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Tanggal Kembali:</span>
            <span class="value"><?php echo isset($data['tgl_kembali']) ? date('d-m-Y', strtotime($data['tgl_kembali'])) : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Total Bayar:</span>
            <span class="value"><?php echo isset($data['total']) ? number_format($data['total'], 2, ',', '.') : '0.00'; ?></span>
        </div>
        <div class="info">
            <span class="label">Denda:</span>
            <span class="value"><?php echo isset($data['denda']) ? number_format($data['denda'], 2, ',', '.') : '0.00'; ?></span>
        </div>
        <div class="info">
            <span class="label">Status Pelunasan:</span>
            <span class="value"><?php echo isset($data['status_pelunasan']) ? $data['status_pelunasan'] : 'N/A'; ?></span>
        </div>
        <div class="info">
            <span class="label">Kondisi Mobil:</span>
            <span class="value"><?php echo isset($data['kondisi_mobil']) ? $data['kondisi_mobil'] : 'N/A'; ?></span>
        </div>
    </div>

    <div class="footer">
        <p>Terima kasih atas kepercayaan Anda menggunakan layanan kami!</p>
        <button class="no-print" onclick="window.print()">Cetak Kwitansi</button> <!-- Tombol cetak -->
    </div>

    <script>
        window.print();
        setTimeout(function() {
            window.close();
        }, 100);
    </script>

</body>
</html>
