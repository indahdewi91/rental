<?php
    include "koneksi.php"; // Koneksi ke database
    session_start(); // Memulai session
    
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['nik'])) {
        header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
        exit();
    }
    
    
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Rentall Digital</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="img\.png"> 
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

    <style>
         .card {
        border-radius: 10px;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 30px rgba(0, 0, 0, 0.15);
    }
    
    .btn-outline-primary:hover {
        background-color: #5CB377; 
        color: white; 
    }

    .btn-outline-primary {
    --bs-btn-color: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #FFFF;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 21, 163, 98;
    --bs-btn-active-color: #FFFF;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #5cb377;
    --bs-btn-disabled-bg: transparent;
    --bs-gradient: none;
    }

	.btn-info {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 77, 130, 199;
    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #5cb377;
    --bs-btn-disabled-border-color: #5cb377;
}

.btn-primary {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5b99ea ;
    --bs-btn-border-color: #5b99ea ;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5b99ea;
    --bs-btn-hover-border-color: #5b99ea;
    --bs-btn-focus-shadow-rgb: 18, 139, 83;
    --bs-btn-active-color: #ffff;
    --bs-btn-active-bg: #44b581;
    --bs-btn-active-border-color: #2cac72;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #15a362;
    --bs-btn-disabled-border-color: #15a362;
}
</style>



</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
			<div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            
		            <div class="app-utilities col-auto">
			            
			            <div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img src="assets/images/user.png" alt="user profile"></a>
				            <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="../logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown-->  
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel sidepanel-hidden"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="index.php"><span class="logo-text">Rentall</span></a>
	
		        </div><!--//app-branding-->  
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="index.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Beranda</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="mobil.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-car-front" viewBox="0 0 16 16">
  <path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0m10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0M6 8a1 1 0 0 0 0 2h4a1 1 0 1 0 0-2zM4.862 4.276 3.906 6.19a.51.51 0 0 0 .497.731c.91-.073 2.35-.17 3.597-.17s2.688.097 3.597.17a.51.51 0 0 0 .497-.731l-.956-1.913A.5.5 0 0 0 10.691 4H5.309a.5.5 0 0 0-.447.276"/>
  <path d="M2.52 3.515A2.5 2.5 0 0 1 4.82 2h6.362c1 0 1.904.596 2.298 1.515l.792 1.848c.075.175.21.319.38.404.5.25.855.715.965 1.262l.335 1.679q.05.242.049.49v.413c0 .814-.39 1.543-1 1.997V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.338c-1.292.048-2.745.088-4 .088s-2.708-.04-4-.088V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.892c-.61-.454-1-1.183-1-1.997v-.413a2.5 2.5 0 0 1 .049-.49l.335-1.68c.11-.546.465-1.012.964-1.261a.8.8 0 0 0 .381-.404l.792-1.848ZM4.82 3a1.5 1.5 0 0 0-1.379.91l-.792 1.847a1.8 1.8 0 0 1-.853.904.8.8 0 0 0-.43.564L1.03 8.904a1.5 1.5 0 0 0-.03.294v.413c0 .796.62 1.448 1.408 1.484 1.555.07 3.786.155 5.592.155s4.037-.084 5.592-.155A1.48 1.48 0 0 0 15 9.611v-.413q0-.148-.03-.294l-.335-1.68a.8.8 0 0 0-.43-.563 1.8 1.8 0 0 1-.853-.904l-.792-1.848A1.5 1.5 0 0 0 11.18 3z"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Daftar Mobil</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
                        <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="koleksi.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-columns-gap" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M6 1H1v3h5V1zM1 0a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1H1zm14 12h-5v3h5v-3zm-5-1a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-5zM6 8H1v7h5V8zM1 7a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1H1zm14-6h-5v7h5V1zm-5-1a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1h-5z"></path>
	</svg>
						         </span>
		                         <span class="nav-link-text">Koleksi</span>
					        </a><!--//nav-link-->
					    </li>
					    
				    </ul><!--//app-menu-->
			    </nav><!--//app-nav-->
			    
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->
    
    <div class="app-wrapper">


    <div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
    <h1 class="text-center mb-4" style="font-size: 2.5rem; font-weight: bold; color: #2d2d2d;">
    Rental Mobil
</h1>
<p class="text-center mb-4"  style="font-size: 1.25rem;  color:#5cb377; line-height: 1.5;">
    Temukan berbagai mobil menarik di sini dan jadikan perjalananmu lebih istimewa!
</p>


        <div class="mb-3">
            <input type="text" id="search" class="form-control" placeholder="Cari mobil..." style="max-width: 1500px; margin: auto;">
        </div>

        <div class="tab-content" id="orders-table-tab-content">
            <div class="row" id="car-list">
                <?php
                $mobil_query = "SELECT * FROM mobil WHERE status = 'tersedia'";
                $mobil_result = mysqli_query($koneksi, $mobil_query);

                // Periksa apakah query berhasil
                if ($mobil_result === false) {
                    die('Error executing query: ' . mysqli_error($koneksi));
                }

                while ($row = mysqli_fetch_assoc($mobil_result)) {
                    $imageFileName = $row['foto'];
                ?>
                    <div class="col-md-4 mb-4 car-item">
                        <div class="card h-100 shadow" style="border-radius: 10px; border: 1px solid #e0e0e0; transition: transform 0.2s;">
                            <a href="sewa.php?nopol=<?php echo $row['nopol']; ?>" class="text-decoration-none text-white">
                                <img src="../img/<?php echo $imageFileName; ?>" class="card-img-top" alt="Gambar Mobil" style="height: 200px; object-fit: contain; border-radius: 10px 10px 0 0; background-color: #f8f8f8;">
                                <div class="card-body d-flex flex-column" style="background-color: #5cb377; border-radius: 0 0 10px 10px;">
                                    <h5 class="card-title" style="font-size: 1.2rem; font-weight: bold; color: white;"><?php echo $row['brand'] . ' - ' . $row['nopol']; ?></h5>
                                    <p class="card-text" style="font-size: 1.1rem; color: #f8f8f8;">Harga: Rp <?php echo number_format($row['harga'], 2, ',', '.'); ?>/hari</p>
                                    <div class="mt-auto">
                                        <form action="sewa.php" method="GET">
                                            <input type="hidden" name="nopol" value="<?= $row['nopol']; ?>"> 
                                            <button type="submit" class="btn btn-light" style="border-radius: 5px; width: 100%;">Sewa</button>
                                        </form>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php 
                }
                ?>
            </div>
        </div>
    </div>
</div>


	
	
		<!-- Modal -->
<div class="modal fade" id="returnModal" tabindex="-1" aria-labelledby="returnModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="returnModalLabel">Informasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-message">
                <!-- Pesan akan ditambahkan di sini -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary" onclick="window.location.href='buku.php'">Kembali ke Daftar Buku</button>
            </div>
        </div>
    </div>
</div>
                </div>

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    // Pencarian mobil
    document.getElementById('search').addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const items = document.querySelectorAll('.car-item');
        items.forEach(item => {
            const title = item.querySelector('.card-title').textContent.toLowerCase();
            if (title.includes(query)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>
</body>

</body>
</html> 
