<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Rental Mobil</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="img/.png"> 
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

</head> 

<body class="app app-signup p-0">    	
    <div class="row g-0 app-auth-wrapper">
	    <div class="col-12 col-md-7 col-lg-6 auth-main-col text-center p-5">
		    <div class="d-flex flex-column align-content-end">
			    <div class="app-auth-body mx-auto">	
				    <div class="app-auth-branding mb-4"></div>
					<h2 class="auth-heading text-center mb-4">Register ke Rentall</h2>					
	
					<div class="auth-form-container text-start mx-auto">
					<form action="" method="POST" class="auth-form auth-signup-form">         
    <div class="nik mb-3">
        <label class="sr-only" for="signup-nik">NIK</label>
        <input id="signup-nik" name="nik" type="text" class="form-control signup-nik" placeholder="NIK" required="required" >
    </div>
    <div class="nama mb-3">
        <label class="sr-only" for="signup-nama">Nama Lengkap</label>
        <input id="signup-nama" name="nama" type="text" class="form-control signup-nama" placeholder="Nama Lengkap" required="required" >
    </div>
    <div class="jk mb-3">
        <label class="sr-only" for="signup-jk">Jenis Kelamin</label>
        <select id="signup-jk" name="jk" class="form-select" required="required">
            <option value="l">Laki-laki</option>
            <option value="p">Perempuan</option>
        </select>
    </div>
    <div class="telp mb-3">
        <label class="sr-only" for="signup-telp">Telepon</label>
        <input id="signup-telp" name="telp" type="text" class="form-control signup-telp" placeholder="Telepon" required="required" >
    </div>
    <div class="alamat mb-3">
        <label class="sr-only" for="signup-alamat">Alamat</label>
        <input id="signup-alamat" name="alamat" type="text" class="form-control signup-alamat" placeholder="Alamat" required="required" >
    </div>
    <div class="username mb-3">
        <label class="sr-only" for="signup-username">Username</label>
        <input id="signup-username" name="username" type="text" class="form-control signup-username" placeholder="Username" required="required" >
    </div>
    <div class="password mb-3">
        <label class="sr-only" for="signup-password">Password</label>
        <input id="signup-password" name="password" type="password" class="form-control signup-password" placeholder="Buat password" required="required" >
    </div>
    
    <div class="text-center">
        <button type="submit" class="btn app-btn-primary w-100 theme-btn mx-auto" value="submit" name="submit">Daftar</button>
    </div>
</form>

<?php
require('koneksi.php'); // Koneksi ke database

if (isset($_POST['nik'])) {
    $nik = stripslashes($_POST['nik']);
    $nik = mysqli_real_escape_string($koneksi, $nik);
    $nama = stripslashes($_POST['nama']);
    $nama = mysqli_real_escape_string($koneksi, $nama);
    $jk = stripslashes($_POST['jk']);
    $jk = mysqli_real_escape_string($koneksi, $jk);
    $telp = stripslashes($_POST['telp']);
    $telp = mysqli_real_escape_string($koneksi, $telp);
    $alamat = stripslashes($_POST['alamat']);
    $alamat = mysqli_real_escape_string($koneksi, $alamat);
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($koneksi, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($koneksi, $password);
    
    // Periksa apakah username sudah ada
    $sql = "SELECT nik FROM member WHERE username = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "Username sudah terdaftar. Silakan gunakan username lain.";
    } else {
        // Simpan data pengguna baru ke tabel member
        $query = "INSERT INTO `member` (nik, nama, jk, telp, alamat, username, password) 
                  VALUES ('$nik', '$nama', '$jk', '$telp', '$alamat', '$username', '".md5($password)."')";
        $result = mysqli_query($koneksi, $query);
        
        if ($result) {
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    alert('Registrasi berhasil!');
                    setTimeout(function() {
                        window.location.href = 'login.php';
                    }, 2000);
                });
            </script>";
        } else {
            echo "Terjadi kesalahan dalam proses registrasi.";
        }
    }
}
?>



                        <div id="myModal" class="modal">
                            <div class="modal-content">
                                <span class="close">&times;</span>
                                <p id="modalMessage">User sudah terdaftar. Silakan gunakan email atau username lain.</p>
                            </div>
                        </div>

                        
						
						<div class="auth-option text-center pt-5">Sudah punya akun? <a class="text-link" href="login.php" >Masuk</a></div>
					</div><!--//auth-form-container-->	
					
					
				    
			    </div><!--//auth-body-->
		    
			    <footer class="app-auth-footer">
				    <div class="container text-center py-3">
				         <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
			        <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart" style="color: #fb866a;"></i> by <a class="app-link" href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
				       
				    </div>
			    </footer><!--//app-auth-footer-->	
		    </div><!--//flex-column-->   
	    </div><!--//auth-main-col-->
	    <div class="col-12 col-md-5 col-lg-6 h-100 auth-background-col">
		    <div class="auth-background-holder">			    
		    </div>
		    <div class="auth-background-mask"></div>
		    <div class="auth-background-overlay p-3 p-lg-5">
			    <div class="d-flex flex-column align-content-end h-100">
				    <div class="h-100"></div>
                    <div class="auth-background-mask"></div>
		    <div class="auth-background-overlay p-3 p-lg-5">
			    <div class="d-flex flex-column align-content-end h-100">
				    <div class="h-100"></div>
				    <div class="overlay-content p-3 p-lg-4 rounded">
					    <h5 class="mb-3 overlay-title">PU</h5>
					    <div>Permis satu: Jika hujan saya tidak sekolah </br>Permis dua: Saya tidak sekolah...?</div>
				    </div>
				</div>
		    </div><!--//auth-background-overlay-->
				</div>
		    </div><!--//auth-background-overlay-->
	    </div><!--//auth-background-col-->
    
    </div><!--//row-->
	<div id="customAlert" class="custom-alert">
    <span class="alert-text">RentAll: Anda Berhasil Sign up</span>
</div>

<script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 

</body>

</html> 

