<?php
include "koneksi.php"; // Koneksi ke database
session_start(); // Memulai session

// Cek apakah pengguna sudah login dan memiliki akses
if (!isset($_SESSION['id_user']) ) {
    header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
    exit();
}

// Cek apakah ada id yang dikirim melalui GET
if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    // Mengupdate status transaksi menjadi 'approve'
    $query = "UPDATE transaksi SET status='approve' WHERE id_transaksi='$id_transaksi'";

    if (mysqli_query($koneksi, $query)) {
        // Dapatkan nopol mobil dari transaksi untuk memperbarui status mobil
        $query_mobil = "SELECT nopol FROM transaksi WHERE id_transaksi='$id_transaksi'";
        $result_mobil = mysqli_query($koneksi, $query_mobil);
        
        if ($row_mobil = mysqli_fetch_assoc($result_mobil)) {
            $nopol = $row_mobil['nopol'];

            // Mengupdate status mobil menjadi 'tidak_tersedia'
            $query_update_mobil = "UPDATE mobil SET status='tidak' WHERE nopol='$nopol'";
            mysqli_query($koneksi, $query_update_mobil);
        }

        // Jika berhasil, arahkan kembali ke dashboard atau halaman lain
        header("Location: coba1.php?message=Transaksi berhasil disetujui");
        exit();
    } else {
        // Jika gagal, tampilkan pesan error
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    echo "ID transaksi tidak ditemukan.";
}

mysqli_close($koneksi); // Tutup koneksi
?>
