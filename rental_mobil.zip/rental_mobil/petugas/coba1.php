<?php
include "koneksi.php"; // Koneksi ke database
session_start(); // Memulai session

// Cek apakah pengguna sudah login
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
    exit();
}
function safeDisplay($value)
{
    return isset($value) ? htmlspecialchars($value) : '-';
}

// Kode untuk menangani setiap tab
$statuses = ['booking', 'approve', 'ambil', 'kembali'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Rentall Digital</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">
    <link rel="shortcut icon" href="">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>

    <!-- Memuat CSS Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Memuat jQuery dan JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- App CSS -->
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

    <style>
        .table {
            width: 100%;
            /* Memastikan tabel menggunakan 100% lebar kontainer */
            table-layout: fixed;
            /* Mengatur tata letak tetap */
            overflow: hidden;
            /* Menghindari overflow */
        }

        .table th,
        .table td {
            word-wrap: break-word;
            /* Memungkinkan pemotongan kata yang panjang */
            text-overflow: ellipsis;
            /* Menambahkan ellipsis jika teks terlalu panjang */
            overflow: hidden;
            /* Menghindari overflow pada sel */
        }

        .table img {
            max-width: 80px;
            /* Membatasi lebar gambar */
            height: auto;
            /* Mempertahankan rasio aspek gambar */
        }

        @media (max-width: 768px) {

            .table th,
            .table td {
                padding: 8px;
                /* Mengurangi padding pada perangkat kecil */
                font-size: 14px;
                /* Mengurangi ukuran font */
            }

            .table {
                font-size: 12px;
                /* Ukuran font lebih kecil untuk tampilan yang lebih baik */
            }
        }

        .pagination .page-link {
            color: #5CB377;
            /* Warna teks */
        }

        .pagination .page-link:hover {
            background-color: #5CB377;
            /* Warna background saat hover */
            color: white;
            /* Warna teks saat hover */
        }

        .pagination .page-item.active .page-link {
            background-color: #5CB377;
            /* Warna background halaman aktif */
            border-color: #5CB377;
            /* Warna border halaman aktif */
            color: white;
            /* Warna teks halaman aktif */
        }

        .pagination .page-item.disabled .page-link {
            color: #d3d3d3;
            /* Warna teks untuk tombol yang disabled */
        }

        .btn-outline-primary:hover {
            background-color: #5CB377;
            color: white;
        }

        .btn-outline-primary {
            --bs-btn-color: #5cb377;
            --bs-btn-border-color: #5cb377;
            --bs-btn-hover-color: #FFFF;
            --bs-btn-hover-bg: #5cb377;
            --bs-btn-hover-border-color: #5cb377;
            --bs-btn-focus-shadow-rgb: 21, 163, 98;
            --bs-btn-active-color: #FFFF;
            --bs-btn-active-bg: #5cb377;
            --bs-btn-active-border-color: #5cb377;
            --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            --bs-btn-disabled-color: #5cb377;
            --bs-btn-disabled-bg: transparent;
            --bs-gradient: none;
        }

        .btn-info {
            --bs-btn-color: #ffff;
            --bs-btn-bg: #5cb377;
            --bs-btn-border-color: #5cb377;
            --bs-btn-hover-color: #ffff;
            --bs-btn-hover-bg: #5cb377;
            --bs-btn-hover-border-color: #5cb377;
            --bs-btn-focus-shadow-rgb: 77, 130, 199;
            --bs-btn-active-color: #fff;
            --bs-btn-active-bg: #5cb377;
            --bs-btn-active-border-color: #5cb377;
            --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            --bs-btn-disabled-color: #ffff;
            --bs-btn-disabled-bg: #5cb377;
            --bs-btn-disabled-border-color: #5cb377;
        }

        .btn-primary {
            --bs-btn-color: #ffff;
            --bs-btn-bg: #5b99ea;
            --bs-btn-border-color: #5b99ea;
            --bs-btn-hover-color: #ffff;
            --bs-btn-hover-bg: #5b99ea;
            --bs-btn-hover-border-color: #5b99ea;
            --bs-btn-focus-shadow-rgb: 18, 139, 83;
            --bs-btn-active-color: #ffff;
            --bs-btn-active-bg: #44b581;
            --bs-btn-active-border-color: #2cac72;
            --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
            --bs-btn-disabled-color: #ffff;
            --bs-btn-disabled-bg: #15a362;
            --bs-btn-disabled-border-color: #15a362;
        }
    </style>

</head>

<body class="app">
    <header class="app-header fixed-top">
        <div class="app-header-inner">
            <div class="container-fluid py-2">
                <div class="app-header-content">
                    <div class="row justify-content-between align-items-center">

                        <div class="col-auto">
                            <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img">
                                    <title>Menu</title>
                                    <path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path>
                                </svg>
                            </a>
                        </div><!--//col-->

                        <div class="app-utilities col-auto">

                            <div class="app-utility-item app-user-dropdown dropdown">
                                <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img src="assets/images/user.png" alt="user profile"></a>
                                <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
                                    <li><a class="dropdown-item" href="../logout.php">Log Out</a></li>
                                </ul>
                            </div><!--//app-user-dropdown-->
                        </div><!--//app-utilities-->
                    </div><!--//row-->
                </div><!--//app-header-content-->
            </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel sidepanel">
            <div id="sidepanel-drop" class="sidepanel-drop"></div>
            <div class="sidepanel-inner d-flex flex-column">
                <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">×</a>
                <div class="app-branding">
                    <a class="app-logo" href="coba1.php"><span class="logo-text">Rentall</span></a>

                </div><!--//app-branding-->
                <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
                    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
                        <li class="nav-item">
                            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                            <a class="nav-link active" href="coba1.php">
                                <span class="nav-icon">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-card-list" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" />
                                        <path fill-rule="evenodd" d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5z" />
                                        <circle cx="3.5" cy="5.5" r=".5" />
                                        <circle cx="3.5" cy="8" r=".5" />
                                        <circle cx="3.5" cy="10.5" r=".5" />
                                    </svg>
                                </span>
                                <span class="nav-link-text">Dashboard</span>
                            </a><!--//nav-link-->
                        </li><!--//nav-item-->
                        <li class="nav-item">
                            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                            <a class="nav-link" href="daftarmobil.php">
                                <span class="nav-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-car-front" viewBox="0 0 16 16">
                                        <path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0m10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0M6 8a1 1 0 0 0 0 2h4a1 1 0 1 0 0-2zM4.862 4.276 3.906 6.19a.51.51 0 0 0 .497.731c.91-.073 2.35-.17 3.597-.17s2.688.097 3.597.17a.51.51 0 0 0 .497-.731l-.956-1.913A.5.5 0 0 0 10.691 4H5.309a.5.5 0 0 0-.447.276" />
                                        <path d="M2.52 3.515A2.5 2.5 0 0 1 4.82 2h6.362c1 0 1.904.596 2.298 1.515l.792 1.848c.075.175.21.319.38.404.5.25.855.715.965 1.262l.335 1.679q.05.242.049.49v.413c0 .814-.39 1.543-1 1.997V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.338c-1.292.048-2.745.088-4 .088s-2.708-.04-4-.088V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.892c-.61-.454-1-1.183-1-1.997v-.413a2.5 2.5 0 0 1 .049-.49l.335-1.68c.11-.546.465-1.012.964-1.261a.8.8 0 0 0 .381-.404l.792-1.848ZM4.82 3a1.5 1.5 0 0 0-1.379.91l-.792 1.847a1.8 1.8 0 0 1-.853.904.8.8 0 0 0-.43.564L1.03 8.904a1.5 1.5 0 0 0-.03.294v.413c0 .796.62 1.448 1.408 1.484 1.555.07 3.786.155 5.592.155s4.037-.084 5.592-.155A1.48 1.48 0 0 0 15 9.611v-.413q0-.148-.03-.294l-.335-1.68a.8.8 0 0 0-.43-.563 1.8 1.8 0 0 1-.853-.904l-.792-1.848A1.5 1.5 0 0 0 11.18 3z" />
                                    </svg>
                                </span>
                                <span class="nav-link-text">Kelola Koleksi</span>
                            </a><!--//nav-link-->
                        </li><!--//nav-item-->

                        <li class="nav-item">
                            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                            <a class="nav-link" href="daftaruser.php">
                                <span class="nav-icon">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm6 5c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"></path>
                                    </svg>
                                </span>
                                <span class="nav-link-text">Daftar Member</span>
                            </a><!--//nav-link-->
                        </li>
                        <li class="nav-item">
                            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                            <a class="nav-link" href="laporan.php">
                                <span class="nav-icon">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-receipt" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M1.92.506a.5.5 0 0 1 .434.14L3 1.293l.646-.647a.5.5 0 0 1 .708 0L5 1.293l.646-.647a.5.5 0 0 1 .708 0L7 1.293l.646-.647a.5.5 0 0 1 .708 0L9 1.293l.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .801.13l.5 1A.5.5 0 0 1 15 2v12a.5.5 0 0 1-.053.224l-.5 1a.5.5 0 0 1-.8.13L13 14.707l-.646.647a.5.5 0 0 1-.708 0L11 14.707l-.646.647a.5.5 0 0 1-.708 0L9 14.707l-.646.647a.5.5 0 0 1-.708 0L7 14.707l-.646.647a.5.5 0 0 1-.708 0L5 14.707l-.646.647a.5.5 0 0 1-.708 0L3 14.707l-.646.647a.5.5 0 0 1-.801-.13l-.5-1A.5.5 0 0 1 1 14V2a.5.5 0 0 1 .053-.224l.5-1a.5.5 0 0 1 .367-.27zm.217 1.338L2 2.118v11.764l.137.274.51-.51a.5.5 0 0 1 .707 0l.646.647.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.509.509.137-.274V2.118l-.137-.274-.51.51a.5.5 0 0 1-.707 0L12 1.707l-.646.647a.5.5 0 0 1-.708 0L10 1.707l-.646.647a.5.5 0 0 1-.708 0L8 1.707l-.646.647a.5.5 0 0 1-.708 0L6 1.707l-.646.647a.5.5 0 0 1-.708 0L4 1.707l-.646.647a.5.5 0 0 1-.708 0l-.509-.51z"></path>
                                        <path fill-rule="evenodd" d="M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5zm8-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z"></path>
                                    </svg>
                                </span>
                                <span class="nav-link-text">Laporan</span>
                            </a><!--//nav-link-->
                        </li>


                    </ul><!--//app-menu-->
                </nav><!--//app-nav-->

            </div><!--//sidepanel-inner-->
        </div><!--//app-sidepanel-->
    </header><!--//app-header-->

    <div class="app-wrapper">

        <div class="app-content pt-3 p-md-3 p-lg-4">
            <div class="row g-3 mb-4 align-items-center justify-content-between">
                <div class="col-auto">
                    <h1 class="app-page-title mb-0">Penegloaan Penyewaan Mobil</h1>
                </div>
                <div class="col-auto">
                    <div class="page-utilities">
                        <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                           
                        </div>
                    </div>
                </div>
            </div>

            <nav id="transactions-table-tab" class="transactions-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4" role="tablist">
                <a class="flex-sm-fill text-sm-center nav-link active" id="transactions-booking-tab" data-bs-toggle="tab" href="#transactions-booking" role="tab" aria-controls="transactions-booking" aria-selected="true">Booking</a>
                <a class="flex-sm-fill text-sm-center nav-link" id="transactions-approve-tab" data-bs-toggle="tab" href="#transactions-approve" role="tab" aria-controls="transactions-approve" aria-selected="false" tabindex="-1">Approve</a>
                <a class="flex-sm-fill text-sm-center nav-link" id="transactions-ambil-tab" data-bs-toggle="tab" href="#transactions-ambil" role="tab" aria-controls="transactions-ambil" aria-selected="false" tabindex="-1">Ambil</a>
                <a class="flex-sm-fill text-sm-center nav-link" id="transactions-kembali-tab" data-bs-toggle="tab" href="#transactions-kembali" role="tab" aria-controls="transactions-kembali" aria-selected="false" tabindex="-1">Kembali</a>
            </nav>

            <div class="tab-content" id="transactions-table-tab-content">
                <!-- Tab Booking -->
                <div class="tab-pane fade active show" id="transactions-booking" role="tabpanel" aria-labelledby="transactions-booking-tab">
                    <div class="app-card app-card-transactions-table shadow-sm mb-5">
                        <div class="app-card-body">
                            <div class="table-responsive">
                                <table class="table app-table-hover mb-0 text-left">
                                    <thead>
                                        <tr>
                                            <th class="cell">Order</th>
                                            <th class="cell">Customer</th>
                                            <th class="cell">Nopol Mobil</th>
                                            <th class="cell">Start Date</th>
                                            <th class="cell">End Date</th>
                                            <th class="cell">Status</th>
                                            <th class="cell"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Query untuk mengambil data booking
                                        $query = "
                                SELECT t.*, m.nama AS nama 
                                FROM transaksi t 
                                JOIN member m ON t.nik = m.nik 
                                WHERE t.status='booking'";

                                        $result = mysqli_query($koneksi, $query);

                                        if ($result) {
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nama'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'><span class='badge bg-warning'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                                                    echo "<td class='cell'><a class='btn-sm app-btn-secondary' href='approve.php?id=" . safeDisplay($row['id_transaksi'] ?? '-') . "'>Approve</a></td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data booking</td></tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Approve -->
                <div class="tab-pane fade" id="transactions-approve" role="tabpanel" aria-labelledby="transactions-approve-tab">
                    <div class="app-card app-card-transactions-table shadow-sm mb-5">
                        <div class="app-card-body">
                            <div class="table-responsive">
                                <table class="table app-table-hover mb-0 text-left">
                                    <thead>
                                        <tr>
                                            <th class="cell">Order</th>
                                            <th class="cell">Customer</th>
                                            <th class="cell">Nopol Mobil</th>
                                            <th class="cell">Start Date</th>
                                            <th class="cell">End Date</th>
                                            <th class="cell">Status</th>
                                            <th class="cell"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "
                                SELECT t.*, m.nama 
                                FROM transaksi t 
                                JOIN member m ON t.nik = m.nik 
                                WHERE t.status='approve'";
                                        $result = mysqli_query($koneksi, $query);

                                        if ($result) {
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nama'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'><span class='badge bg-success'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                                                    echo "<td class='cell'><a class='btn-sm app-btn-secondary' href='ambil.php?id=" . safeDisplay($row['id_transaksi'] ?? '-') . "'>Ambil</a></td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data yang disetujui</td></tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Ambil -->
                <div class="tab-pane fade" id="transactions-ambil" role="tabpanel" aria-labelledby="transactions-ambil-tab">
                    <div class="app-card app-card-transactions-table shadow-sm mb-5">
                        <div class="app-card-body">
                            <div class="table-responsive">
                                <table class="table app-table-hover mb-0 text-left">
                                    <thead>
                                        <tr>
                                            <th class="cell">Order</th>
                                            <th class="cell">Customer</th>
                                            <th class="cell">Nopol Mobil</th>
                                            <th class="cell">Start Date</th>
                                            <th class="cell">End Date</th>
                                            <th class="cell">Status</th>
                                            <th class="cell"></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Contoh data dari database
                                        $query = "
                SELECT t.*, m.nama 
                FROM transaksi t 
                JOIN member m ON t.nik = m.nik 
                WHERE t.status='ambil'";
                                        $result = mysqli_query($koneksi, $query);

                                        if ($result) {
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nama'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                                                    echo "<td class='cell'><span class='badge bg-info'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                                                    echo "<td class='cell'><button class='btn-sm app-btn-secondary' data-toggle='modal' data-target='#kembaliModal' data-id='" . safeDisplay($row['id_transaksi'] ?? '-') . "' data-nopol='" . safeDisplay($row['nopol'] ?? '-') . "'>Kembali</button></td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data yang diambil</td></tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Modal untuk Kembali -->
<div class="modal fade" id="kembaliModal" tabindex="-1" role="dialog" aria-labelledby="kembaliModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kembaliModalLabel">Kembalikan Mobil</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="kembali.php" method="POST">
                    <input type="hidden" name="id_transaksi" id="modalIdTransaksi">
                    <input type="hidden" name="tgl_kembali" id="modalTglKembali">

                    <div class="form-group">
                        <label for="kondisi_mobil">Kondisi Mobil</label>
                        <textarea class="form-control" id="kondisi_mobil" name="kondisi_mobil" required></textarea>
                    </div>

                    <!-- Denda Keterlambatan (Auto-calculated) -->
                    <div class="form-group">
                        <label for="late_days">Jumlah Hari Terlambat</label>
                        <input type="number" class="form-control" id="late_days" name="late_days" value="0" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label for="denda_telat">Denda Keterlambatan (Rp)</label>
                        <input type="number" class="form-control" id="denda_telat" name="denda_telat" value="0" readonly>
                    </div>

                    <!-- Denda Kondisi Mobil (Manual input by user) -->
                    <div class="form-group">
                        <label for="denda_kondisi">Denda Kerusakan (Rp)</label>
                        <input type="number" class="form-control" id="denda_kondisi" name="denda_kondisi" value="0" min="0">
                    </div>

                    <!-- Total Denda -->
                    <div class="form-group">
                        <label for="total_denda">Total Denda (Rp)</label>
                        <input type="number" class="form-control" id="total_denda" name="total_denda" value="0" readonly>
                    </div>

                    <button type="submit" class="btn btn-primary">Kembalikan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Script untuk mengisi modal dengan data dari tombol Kembali dan menghitung keterlambatan
    $('#kembaliModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Tombol yang memicu modal
        var idTransaksi = button.data('id'); // Ambil data-id
        var tglKembali = button.data('tgl-kembali'); // Ambil tanggal kembali dari tombol

        var modal = $(this);
        modal.find('#modalIdTransaksi').val(idTransaksi); // Isi id_transaksi di modal
        modal.find('#modalTglKembali').val(tglKembali); // Isi tanggal kembali di modal

        // Ambil tanggal saat ini
        var today = new Date();
        var returnDate = new Date(tglKembali);

        // Hitung selisih hari jika terlambat
        if (today > returnDate) {
            var diffTime = Math.abs(today - returnDate);
            var lateDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // Menghitung jumlah hari keterlambatan

            // Hitung denda berdasarkan hari terlambat (misalnya Rp 50.000 per hari terlambat)
            var dendaPerHari = 600000;
            var dendaTelat = lateDays * dendaPerHari;

            // Tampilkan jumlah hari terlambat dan denda
            modal.find('#late_days').val(lateDays);
            modal.find('#denda_telat').val(dendaTelat);
            modal.find('#late-fee-container').show();
        } else {
            // Jika tidak terlambat, sembunyikan input denda keterlambatan
            modal.find('#late_days').val(0);
            modal.find('#denda_telat').val(0);
            modal.find('#late-fee-container').hide();
        }

        // Event listener untuk menghitung total denda ketika denda kerusakan diubah
        $('#denda_kondisi').on('input', function () {
            var dendaTelat = parseInt(modal.find('#denda_telat').val()) || 0;
            var dendaKondisi = parseInt($(this).val()) || 0;
            var totalDenda = dendaTelat + dendaKondisi;
            
            // Set total denda
            modal.find('#total_denda').val(totalDenda);
        });
    });
</script>


                <!-- Tab Kembali -->
                <div class="tab-pane fade" id="transactions-kembali" role="tabpanel" aria-labelledby="transactions-kembali-tab">
                    <div class="app-card app-card-transactions-table shadow-sm mb-5">
                        <div class="app-card-body">
                            <div class="table-responsive">
                                <table class="table mb-0 text-left">
                                    <thead>
                                        <tr>
                                            <th class="cell">Order</th>
                                            <th class="cell">Customer</th>
                                            <th class="cell">Nopol Mobil</th>
                                            <th class="cell">Tanggal Bayar</th>
                                            <th class="cell">Total Bayar</th>
                                            <th class="cell">Status</th>
                                            <th class="cell">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "
                        SELECT 
                            k.id_kembali, 
                            k.denda, 
                            b.tgl_bayar, 
                            b.total_bayar, 
                            b.status AS status_pelunasan, 
                            t.id_transaksi, 
                            m.nama AS customer, 
                            c.nopol AS mobil,
                            t.kekurangan,
                            c.harga AS harga,
                            t.downpayment AS dp, 
                            t.total AS total 
                        FROM kembali k 
                        JOIN transaksi t ON k.id_transaksi = t.id_transaksi
                        JOIN member m ON t.nik = m.nik 
                        JOIN mobil c ON t.nopol = c.nopol
                        LEFT JOIN bayar b ON k.id_kembali = b.id_kembali
                        ";

                                        $result = mysqli_query($koneksi, $query);

                                        if ($result) {
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['customer'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . safeDisplay($row['mobil'] ?? '-') . "</td>";
                                                    echo "<td class='cell'>" . (isset($row['tgl_bayar']) ? date('d M Y', strtotime(safeDisplay($row['tgl_bayar']))) : '-') . "</td>";
                                                    echo "<td class='cell'>" . (isset($row['total_bayar']) ? safeDisplay($row['total_bayar']) : '-') . "</td>";

                                                    // Cek status pelunasan
                                                    echo "<td class='cell'>";
                                                    if (isset($row['status_pelunasan'])) {
                                                        if ($row['status_pelunasan'] === 'lunas') {
                                                            echo "<span class='badge bg-success'>Lunas</span>";
                                                        } else {
                                                            echo "<span class='badge bg-danger'>Belum Lunas</span>";
                                                        }
                                                    } else {
                                                        echo "<span class='badge bg-danger'>Belum Lunas</span>"; // Jika tidak ada catatan bayar, tampilkan Belum Lunas
                                                    }
                                                    echo "</td>";

                                                    // Tambahkan tombol untuk konfirmasi pelunasan
                                                    echo "<td class='cell'>";
                                                    if (!isset($row['status_pelunasan']) || $row['status_pelunasan'] !== 'lunas') {
                                                        echo "<button class='btn btn-primary' data-toggle='modal' data-target='#modalPelunasan' 
                                            data-id='" . safeDisplay($row['id_kembali'] ?? '-') . "' 
                                            
                                            data-idtransaksi='" . safeDisplay($row['id_transaksi'] ?? '-') . "' 
                                            data-customer='" . safeDisplay($row['customer'] ?? '-') . "' 
                                            data-mobil='" . safeDisplay($row['mobil'] ?? '-') . "' 
                                            data-kekurangan='" . safeDisplay($row['kekurangan'] ?? '0.00') . "' 
                                            data-harga='" . safeDisplay($row['harga'] ?? '0.00') . "' 
                                            data-denda='" . safeDisplay($row['denda'] ?? '0.00') . "' 
                                            data-total='" . safeDisplay($row['total'] ?? '0.00') . "' 
                                            data-dp='" . safeDisplay($row['dp'] ?? '0.00') . "'>Konfirmasi</button>";
                                                    } else {
                                                        echo "-";
                                                    }
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data pelunasan</td></tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal untuk Konfirmasi Pelunasan -->
                <div class="modal fade" id="modalPelunasan" tabindex="-1" role="dialog" aria-labelledby="modalPelunasanLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalPelunasanLabel">Konfirmasi Pelunasan</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form id="formPelunasan" method="post" action="proses_pelunasan.php">
                                    <input type="hidden" name="id_kembali" id="id_kembali" value="">
                                    <input type="hidden" name="id_transaksi" id="id_transaksi" value="">

                                    <h6>Rincian Pembayaran:</h6>
                                    <div class="form-group">
                                        <label for="customer">Customer</label>
                                        <input type="text" class="form-control" id="customer" name="customer" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="mobil">Mobil</label>
                                        <input type="text" class="form-control" id="mobil" name="mobil" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="harga_per_hari">Harga per Hari</label>
                                        <input type="text" class="form-control" id="harga_per_hari" name="harga_per_hari" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="total_transaksi">Total Transaksi</label>
                                        <input type="text" class="form-control" id="total_transaksi" name="total_transaksi" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="dp">Down Payment</label>
                                        <input type="text" class="form-control" id="dp" name="dp" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="kekurangan">Kekurangan</label>
                                        <input type="text" class="form-control" id="kekurangan" name="kekurangan" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="denda">Denda</label>
                                        <input type="text" class="form-control" id="dendas" name="denda" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="total_bayar">Total Akhir</label>
                                        <input type="text" class="form-control" id="total_bayar" name="total_bayar" readonly>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    $('#modalPelunasan').on('show.bs.modal', function(event) {
                        var button = $(event.relatedTarget); // Tombol yang diklik
                        var idKembali = button.data('id'); // Ambil data id_kembali dari tombol
                        var denda = parseFloat(button.data('denda')) || 0; // Ambil data denda dari tombol, default ke 0
                        var idTransaksi = button.data('idtransaksi'); // Ambil data id_transaksi dari tombol
                        var customer = button.data('customer'); // Ambil data customer dari tombol
                        var mobil = button.data('mobil'); // Ambil data mobil dari tombol
                        var kekurangan = parseFloat(button.data('kekurangan')) || 0; // Ambil data kekurangan dari tombol, default ke 0
                        var hargaPerHari = parseFloat(button.data('harga')) || 0; // Ambil data harga dari tombol, default ke 0
                        var total = parseFloat(button.data('total')) || 0; // Ambil data total dari tombol, default ke 0
                        var dp = parseFloat(button.data('dp')) || 0;

                        // Set value ke form modal
                        var totalAkhir = kekurangan + denda; // Hitung total akhir

                        $('#id_kembali').val(idKembali);
                        $('#id_transaksi').val(idTransaksi);
                        $('#customer').val(customer);
                        $('#mobil').val(mobil);
                        $('#harga_per_hari').val(hargaPerHari);
                        $('#total_transaksi').val(total);
                        $('#dp').val(dp);
                        $('#kekurangan').val(kekurangan);
                        $('#total_bayar').val(totalAkhir); // Tampilkan total akhir
                        let dendac = document.getElementById('dendas').value = denda; // Set nilai denda
                        console.log(dendac);
                        $('#denda').val(denda); // Cek nilai setelah diisi
                    });
                </script>







            </div><!--//app-content-->

            <footer class="app-footer">
                <div class="container text-center py-3">
                    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
                    <small class="copyright">Designed with <span class="sr-only">love</span><svg class="svg-inline--fa fa-heart" style="color: #fb866a;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                            <path fill="currentColor" d="M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z"></path>
                        </svg><!-- <i class="fas fa-heart" style="color: #fb866a;"></i> Font Awesome fontawesome.com --> by <a class="app-link" href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>

                </div>
            </footer><!--//app-footer-->

        </div>


        <style>
            .custom-alert {
                display: none;
                /* Sembunyikan alert secara default */
                position: fixed;
                top: 20px;
                left: 50%;
                transform: translateX(-50%);
                background-color: #28a745;
                /* Warna hijau untuk notifikasi berhasil */
                color: white;
                padding: 15px;
                border-radius: 5px;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
                z-index: 9999;
            }

            .alert-text {
                font-size: 16px;
                font-weight: bold;
            }
        </style>


        <!-- Javascript -->
        <script src="assets/plugins/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

        <!-- Page Specific JS -->
        <script src="assets/js/app.js"></script>
        <!-- Memuat CSS Bootstrap -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

        <!-- Memuat jQuery dan JS Bootstrap -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>






</body>

</html>