<?php
include "koneksi.php"; // Koneksi ke database
session_start(); // Memulai session

// Cek apakah pengguna sudah login
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
    exit();
}


// Cek apakah ada id yang dikirim melalui GET
if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    // Update status transaksi menjadi 'ambil'
    $query = "UPDATE transaksi SET status='ambil' WHERE id_transaksi='$id_transaksi'";

    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil, arahkan kembali ke halaman status sewa dengan pesan sukses
        header("Location: coba1.php?message=Mobil berhasil diambil");
        exit();
    } else {
        // Jika gagal, tampilkan pesan error
        echo "Error: " . mysqli_error($koneksi);
    }
} else {
    echo "ID transaksi tidak ditemukan.";
}

mysqli_close($koneksi); // Tutup koneksi
?>
