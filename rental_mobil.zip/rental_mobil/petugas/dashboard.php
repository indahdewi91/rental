<?php
    include "koneksi.php"; // Koneksi ke database
    session_start(); // Memulai session
    
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'petugas') {
        header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
        exit();
    }
    function safeDisplay($value) {
        return isset($value) ? htmlspecialchars($value) : '-';
    }
    
    // Kode untuk menangani setiap tab
    $statuses = ['booking', 'approve', 'ambil', 'kembali'];
?>


<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Rentall Digital</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="img\.png> 
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- Memuat CSS Bootstrap -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Memuat jQuery dan JS Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

    <style>

.table {
            width: 100%; /* Memastikan tabel menggunakan 100% lebar kontainer */
            table-layout: fixed; /* Mengatur tata letak tetap */
            overflow: hidden; /* Menghindari overflow */
        }

        .table th, .table td {
            word-wrap: break-word; /* Memungkinkan pemotongan kata yang panjang */
            text-overflow: ellipsis; /* Menambahkan ellipsis jika teks terlalu panjang */
            overflow: hidden; /* Menghindari overflow pada sel */
        }

        .table img {
            max-width: 80px; /* Membatasi lebar gambar */
            height: auto; /* Mempertahankan rasio aspek gambar */
        }

        @media (max-width: 768px) {
            .table th, .table td {
                padding: 8px; /* Mengurangi padding pada perangkat kecil */
                font-size: 14px; /* Mengurangi ukuran font */
            }
            
            .table {
                font-size: 12px; /* Ukuran font lebih kecil untuk tampilan yang lebih baik */
            }
        }
        
    .pagination .page-link {
    color: #5CB377; /* Warna teks */
}

.pagination .page-link:hover {
    background-color: #5CB377; /* Warna background saat hover */
    color: white; /* Warna teks saat hover */
}

.pagination .page-item.active .page-link {
    background-color: #5CB377; /* Warna background halaman aktif */
    border-color: #5CB377; /* Warna border halaman aktif */
    color: white; /* Warna teks halaman aktif */
}

.pagination .page-item.disabled .page-link {
    color: #d3d3d3; /* Warna teks untuk tombol yang disabled */
}

    .btn-outline-primary:hover {
        background-color: #5CB377; 
        color: white; 
    }

    .btn-outline-primary {
    --bs-btn-color: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #FFFF;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 21, 163, 98;
    --bs-btn-active-color: #FFFF;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #5cb377;
    --bs-btn-disabled-bg: transparent;
    --bs-gradient: none;
    }

	.btn-info {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 77, 130, 199;
    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #5cb377;
    --bs-btn-disabled-border-color: #5cb377;
}

.btn-primary {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5b99ea ;
    --bs-btn-border-color: #5b99ea ;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5b99ea;
    --bs-btn-hover-border-color: #5b99ea;
    --bs-btn-focus-shadow-rgb: 18, 139, 83;
    --bs-btn-active-color: #ffff;
    --bs-btn-active-bg: #44b581;
    --bs-btn-active-border-color: #2cac72;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #15a362;
    --bs-btn-disabled-border-color: #15a362;
}
</style>

</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <svg class="svg-inline--fa fa-magnifying-glass search-mobile-trigger-icon" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M500.3 443.7l-119.7-119.7c27.22-40.41 40.65-90.9 33.46-144.7C401.8 87.79 326.8 13.32 235.2 1.723C99.01-15.51-15.51 99.01 1.724 235.2c11.6 91.64 86.08 166.7 177.6 178.9c53.8 7.189 104.3-6.236 144.7-33.46l119.7 119.7c15.62 15.62 40.95 15.62 56.57 0C515.9 484.7 515.9 459.3 500.3 443.7zM79.1 208c0-70.58 57.42-128 128-128s128 57.42 128 128c0 70.58-57.42 128-128 128S79.1 278.6 79.1 208z"></path></svg><!-- <i class="search-mobile-trigger-icon fas fa-search"></i> Font Awesome fontawesome.com -->
			        </div><!--//col-->
		            <div class="app-search-box col">
		                <form class="app-search-form">   
							<input type="text" placeholder="Search..." name="search" class="form-control search-input">
							<button type="submit" class="btn search-btn btn-primary" value="Search"><svg class="svg-inline--fa fa-magnifying-glass" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M500.3 443.7l-119.7-119.7c27.22-40.41 40.65-90.9 33.46-144.7C401.8 87.79 326.8 13.32 235.2 1.723C99.01-15.51-15.51 99.01 1.724 235.2c11.6 91.64 86.08 166.7 177.6 178.9c53.8 7.189 104.3-6.236 144.7-33.46l119.7 119.7c15.62 15.62 40.95 15.62 56.57 0C515.9 484.7 515.9 459.3 500.3 443.7zM79.1 208c0-70.58 57.42-128 128-128s128 57.42 128 128c0 70.58-57.42 128-128 128S79.1 278.6 79.1 208z"></path></svg><!-- <i class="fas fa-search"></i> Font Awesome fontawesome.com --></button> 
				        </form>
		            </div><!--//app-search-box-->
		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-bell icon" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2z"></path>
  <path fill-rule="evenodd" d="M8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z"></path>
</svg>
					            <span class="icon-badge">3</span>
					        </a><!--//dropdown-toggle-->
					        
					        <div class="dropdown-menu p-0" aria-labelledby="notifications-dropdown-toggle">
					            <div class="dropdown-menu-header p-3">
						            <h5 class="dropdown-menu-title mb-0">Notifications</h5>
						        </div><!--//dropdown-menu-title-->
						        <div class="dropdown-menu-content">
							       <div class="item p-3">
								        <div class="row gx-2 justify-content-between align-items-center">
									        <div class="col-auto">
										       <img class="profile-image" src="assets/images/profiles/profile-1.png" alt="">
									        </div><!--//col-->
									        <div class="col">
										        <div class="info"> 
											        <div class="desc">Amy shared a file with you. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </div>
											        <div class="meta"> 2 hrs ago</div>
										        </div>
									        </div><!--//col--> 
								        </div><!--//row-->
								        <a class="link-mask" href="#"></a>
							       </div><!--//item-->
							       <div class="item p-3">
								        <div class="row gx-2 justify-content-between align-items-center">
									        <div class="col-auto">
										        <div class="app-icon-holder">
											        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-receipt" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.92.506a.5.5 0 0 1 .434.14L3 1.293l.646-.647a.5.5 0 0 1 .708 0L5 1.293l.646-.647a.5.5 0 0 1 .708 0L7 1.293l.646-.647a.5.5 0 0 1 .708 0L9 1.293l.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .801.13l.5 1A.5.5 0 0 1 15 2v12a.5.5 0 0 1-.053.224l-.5 1a.5.5 0 0 1-.8.13L13 14.707l-.646.647a.5.5 0 0 1-.708 0L11 14.707l-.646.647a.5.5 0 0 1-.708 0L9 14.707l-.646.647a.5.5 0 0 1-.708 0L7 14.707l-.646.647a.5.5 0 0 1-.708 0L5 14.707l-.646.647a.5.5 0 0 1-.708 0L3 14.707l-.646.647a.5.5 0 0 1-.801-.13l-.5-1A.5.5 0 0 1 1 14V2a.5.5 0 0 1 .053-.224l.5-1a.5.5 0 0 1 .367-.27zm.217 1.338L2 2.118v11.764l.137.274.51-.51a.5.5 0 0 1 .707 0l.646.647.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.509.509.137-.274V2.118l-.137-.274-.51.51a.5.5 0 0 1-.707 0L12 1.707l-.646.647a.5.5 0 0 1-.708 0L10 1.707l-.646.647a.5.5 0 0 1-.708 0L8 1.707l-.646.647a.5.5 0 0 1-.708 0L6 1.707l-.646.647a.5.5 0 0 1-.708 0L4 1.707l-.646.647a.5.5 0 0 1-.708 0l-.509-.51z"></path>
	  <path fill-rule="evenodd" d="M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5zm8-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z"></path>
	</svg>
										        </div>
									        </div><!--//col-->
									        <div class="col">
										        <div class="info"> 
											        <div class="desc">You have a new invoice. Proin venenatis interdum est.</div>
											        <div class="meta"> 1 day ago</div>
										        </div>
									        </div><!--//col-->
								        </div><!--//row-->
								        <a class="link-mask" href="#"></a>
							       </div><!--//item-->
							       <div class="item p-3">
								        <div class="row gx-2 justify-content-between align-items-center">
									        <div class="col-auto">
										        <div class="app-icon-holder icon-holder-mono">
											        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-bar-chart-line" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M11 2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v12h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1v-3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3h1V7a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7h1V2zm1 12h2V2h-2v12zm-3 0V7H7v7h2zm-5 0v-3H2v3h2z"></path>
</svg>
										        </div>
									        </div><!--//col-->
									        <div class="col">
										        <div class="info"> 
											        <div class="desc">Your report is ready. Proin venenatis interdum est.</div>
											        <div class="meta"> 3 days ago</div>
										        </div>
									        </div><!--//col-->
								        </div><!--//row-->
								        <a class="link-mask" href="#"></a>
							       </div><!--//item-->
							       <div class="item p-3">
								        <div class="row gx-2 justify-content-between align-items-center">
									        <div class="col-auto">
										       <img class="profile-image" src="assets/images/profiles/profile-2.png" alt="">
									        </div><!--//col-->
									        <div class="col">
										        <div class="info"> 
											        <div class="desc">James sent you a new message.</div>
											        <div class="meta"> 7 days ago</div>
										        </div>
									        </div><!--//col--> 
								        </div><!--//row-->
								        <a class="link-mask" href="#"></a>
							       </div><!--//item-->
						        </div><!--//dropdown-menu-content-->
						        
						        <div class="dropdown-menu-footer p-2 text-center">
							        <a href="#">View all</a>
						        </div>
															
							</div><!--//dropdown-menu-->					        
				        </div><!--//app-utility-item-->
			            <div class="app-utility-item">
				            <a href="settings.html" title="Settings">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-gear icon" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M8.837 1.626c-.246-.835-1.428-.835-1.674 0l-.094.319A1.873 1.873 0 0 1 4.377 3.06l-.292-.16c-.764-.415-1.6.42-1.184 1.185l.159.292a1.873 1.873 0 0 1-1.115 2.692l-.319.094c-.835.246-.835 1.428 0 1.674l.319.094a1.873 1.873 0 0 1 1.115 2.693l-.16.291c-.415.764.42 1.6 1.185 1.184l.292-.159a1.873 1.873 0 0 1 2.692 1.116l.094.318c.246.835 1.428.835 1.674 0l.094-.319a1.873 1.873 0 0 1 2.693-1.115l.291.16c.764.415 1.6-.42 1.184-1.185l-.159-.291a1.873 1.873 0 0 1 1.116-2.693l.318-.094c.835-.246.835-1.428 0-1.674l-.319-.094a1.873 1.873 0 0 1-1.115-2.692l.16-.292c.415-.764-.42-1.6-1.185-1.184l-.291.159A1.873 1.873 0 0 1 8.93 1.945l-.094-.319zm-2.633-.283c.527-1.79 3.065-1.79 3.592 0l.094.319a.873.873 0 0 0 1.255.52l.292-.16c1.64-.892 3.434.901 2.54 2.541l-.159.292a.873.873 0 0 0 .52 1.255l.319.094c1.79.527 1.79 3.065 0 3.592l-.319.094a.873.873 0 0 0-.52 1.255l.16.292c.893 1.64-.902 3.434-2.541 2.54l-.292-.159a.873.873 0 0 0-1.255.52l-.094.319c-.527 1.79-3.065 1.79-3.592 0l-.094-.319a.873.873 0 0 0-1.255-.52l-.292.16c-1.64.893-3.433-.902-2.54-2.541l.159-.292a.873.873 0 0 0-.52-1.255l-.319-.094c-1.79-.527-1.79-3.065 0-3.592l.319-.094a.873.873 0 0 0 .52-1.255l-.16-.292c-.892-1.64.902-3.433 2.541-2.54l.292.159a.873.873 0 0 0 1.255-.52l.094-.319z"></path>
  <path fill-rule="evenodd" d="M8 5.754a2.246 2.246 0 1 0 0 4.492 2.246 2.246 0 0 0 0-4.492zM4.754 8a3.246 3.246 0 1 1 6.492 0 3.246 3.246 0 0 1-6.492 0z"></path>
</svg>
					        </a>
					    </div><!--//app-utility-item-->
			            
			            <div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img src="assets/images/user.png" alt="user profile"></a>
				            <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.html">Account</a></li>
								<li><a class="dropdown-item" href="settings.html">Settings</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="login.html">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">×</a>
		        <div class="app-branding">
		            <a class="app-logo" href="index.php"><span class="logo-text">Rentall</span></a>
	
		        </div><!--//app-branding-->  
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="daftarbuku.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-card-list" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
  <path fill-rule="evenodd" d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5z"/>
  <circle cx="3.5" cy="5.5" r=".5"/>
  <circle cx="3.5" cy="8" r=".5"/>
  <circle cx="3.5" cy="10.5" r=".5"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="daftaruser.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm6 5c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"></path>
</svg>
						         </span>
		                         <span class="nav-link-text">Daftar Member</span>
					        </a><!--//nav-link-->
					    </li>
                        <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="riwayat_pinjam.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-receipt" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.92.506a.5.5 0 0 1 .434.14L3 1.293l.646-.647a.5.5 0 0 1 .708 0L5 1.293l.646-.647a.5.5 0 0 1 .708 0L7 1.293l.646-.647a.5.5 0 0 1 .708 0L9 1.293l.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .801.13l.5 1A.5.5 0 0 1 15 2v12a.5.5 0 0 1-.053.224l-.5 1a.5.5 0 0 1-.8.13L13 14.707l-.646.647a.5.5 0 0 1-.708 0L11 14.707l-.646.647a.5.5 0 0 1-.708 0L9 14.707l-.646.647a.5.5 0 0 1-.708 0L7 14.707l-.646.647a.5.5 0 0 1-.708 0L5 14.707l-.646.647a.5.5 0 0 1-.708 0L3 14.707l-.646.647a.5.5 0 0 1-.801-.13l-.5-1A.5.5 0 0 1 1 14V2a.5.5 0 0 1 .053-.224l.5-1a.5.5 0 0 1 .367-.27zm.217 1.338L2 2.118v11.764l.137.274.51-.51a.5.5 0 0 1 .707 0l.646.647.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.509.509.137-.274V2.118l-.137-.274-.51.51a.5.5 0 0 1-.707 0L12 1.707l-.646.647a.5.5 0 0 1-.708 0L10 1.707l-.646.647a.5.5 0 0 1-.708 0L8 1.707l-.646.647a.5.5 0 0 1-.708 0L6 1.707l-.646.647a.5.5 0 0 1-.708 0L4 1.707l-.646.647a.5.5 0 0 1-.708 0l-.509-.51z"></path>
	  <path fill-rule="evenodd" d="M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5zm8-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z"></path>
	</svg>
						         </span>
		                         <span class="nav-link-text">Laporan</span>
					        </a><!--//nav-link-->
					    </li>

						
				    </ul><!--//app-menu-->
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <nav class="app-nav app-nav-footer">
					    <ul class="app-menu footer-menu list-unstyled">
						    
						    <li class="nav-item">
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        <a class="nav-link" href="../logout.php">
							        <span class="nav-icon">
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0z"/>
  <path fill-rule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708z"/>
</svg>
							        </span>
			                        <span class="nav-link-text">Log out</span>
						        </a><!--//nav-link-->
						    </li><!--//nav-item-->
					    </ul><!--//footer-menu-->
				    </nav>
			    </div><!--//app-sidepanel-footer-->
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->
    
    <div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="row g-3 mb-4 align-items-center justify-content-between">
    <div class="col-auto">
        <h1 class="app-page-title mb-0">Car Rental Management</h1>
    </div>
    <div class="col-auto">
        <div class="page-utilities">
            <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                <div class="col-auto">
                    <form class="table-search-form row gx-1 align-items-center">
                        <div class="col-auto">
                            <input type="text" id="search-transactions" name="searchtransactions" class="form-control search-transactions" placeholder="Search">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn app-btn-secondary">Search</button>
                        </div>
                    </form>
                </div>
                <div class="col-auto">
                    <a class="btn app-btn-secondary" href="#">
                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-download me-1" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"></path>
                            <path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                        </svg>
                        Download Receipt
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<nav id="transactions-table-tab" class="transactions-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4" role="tablist">
    <a class="flex-sm-fill text-sm-center nav-link active" id="transactions-booking-tab" data-bs-toggle="tab" href="#transactions-booking" role="tab" aria-controls="transactions-booking" aria-selected="true">Booking</a>
    <a class="flex-sm-fill text-sm-center nav-link" id="transactions-approve-tab" data-bs-toggle="tab" href="#transactions-approve" role="tab" aria-controls="transactions-approve" aria-selected="false" tabindex="-1">Approve</a>
    <a class="flex-sm-fill text-sm-center nav-link" id="transactions-ambil-tab" data-bs-toggle="tab" href="#transactions-ambil" role="tab" aria-controls="transactions-ambil" aria-selected="false" tabindex="-1">Ambil</a>
    <a class="flex-sm-fill text-sm-center nav-link" id="transactions-kembali-tab" data-bs-toggle="tab" href="#transactions-kembali" role="tab" aria-controls="transactions-kembali" aria-selected="false" tabindex="-1">Kembali</a>
</nav>

<div class="tab-content" id="transactions-table-tab-content">
    <!-- Booking Tab -->
    <div class="tab-pane fade active show" id="transactions-booking" role="tabpanel" aria-labelledby="transactions-booking-tab">
        <div class="app-card app-card-transactions-table shadow-sm mb-5">
            <div class="app-card-body">
                <div class="table-responsive">
                <table class="table app-table-hover mb-0 text-left">
    <thead>
        <tr>
            <th class="cell">Order</th>
            <th class="cell">Customer</th>
            <th class="cell">Car Nopol</th> <!-- Mengganti label -->
            <th class="cell">Start Date</th>
            <th class="cell">End Date</th>
            <th class="cell">Status</th>
            <th class="cell"></th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Pastikan koneksi database berhasil
        if (!$koneksi) {
            die("Koneksi database gagal: " . mysqli_connect_error());
        }

        // Query untuk mengambil data booking
        $query = "
            SELECT t.*, m.nama AS customer_name 
            FROM transaksi t 
            JOIN member m ON t.nik = m.nik 
            WHERE t.status='booking'";
        
        $result = mysqli_query($koneksi, $query);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                    echo "<td class='cell'>" . safeDisplay($row['customer_name'] ?? '-') . "</td>";
                    echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>"; // Menampilkan nopol mobil
                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                    echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                    echo "<td class='cell'><span class='badge bg-warning'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                    echo "<td class='cell'><a class='btn-sm app-btn-secondary' href='approve.php?id=" . safeDisplay($row['id_transaksi'] ?? '-') . "'>Approve</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>Tidak ada data booking</td></tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
        }
        ?>
    </tbody>
</table>

                </div>
            </div>
        </div>
    </div>

    <!-- Approve Tab -->
    <div class="tab-pane fade" id="transactions-approve" role="tabpanel" aria-labelledby="transactions-approve-tab">
        <div class="app-card app-card-transactions-table mb-5">
            <div class="app-card-body">
                <div class="table-responsive">
                    <table class="table mb-0 text-left">
                        <thead>
                            <tr>
                                <th class="cell">Order</th>
                                <th class="cell">Customer</th>
                                <th class="cell">Car</th>
                                <th class="cell">Start Date</th>
                                <th class="cell">End Date</th>
                                <th class="cell">Status</th>
                                <th class="cell"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "
                                SELECT t.*, m.nama 
                                FROM transaksi t 
                                JOIN member m ON t.nik = m.nik 
                                WHERE t.status='approve'";
                            $result = mysqli_query($koneksi, $query);

                            if ($result) {
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                                        echo "<td class='cell'>" . safeDisplay($row['nama'] ?? '-') . "</td>";
                                        echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>";
                                        echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                                        echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                                        echo "<td class='cell'><span class='badge bg-success'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                                        echo "<td class='cell'><a class='btn-sm app-btn-secondary' href='ambil.php?id=" . safeDisplay($row['id_transaksi'] ?? '-') . "'>Ambil</a></td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7' class='text-center'>Tidak ada data yang disetujui</td></tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Ambil Tab -->
    <div class="tab-pane fade" id="transactions-ambil" role="tabpanel" aria-labelledby="transactions-ambil-tab">
        <div class="app-card app-card-transactions-table mb-5">
            <div class="app-card-body">
                <div class="table-responsive">
    <table class="table mb-0 text-left">
        <thead>
            <tr>
                <th class="cell">Order</th>
                <th class="cell">Customer</th>
                <th class="cell">Car</th>
                <th class="cell">Start Date</th>
                <th class="cell">End Date</th>
                <th class="cell">Status</th>
                <th class="cell"></th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Contoh data dari database
            $query = "
                SELECT t.*, m.nama 
                FROM transaksi t 
                JOIN member m ON t.nik = m.nik 
                WHERE t.status='ambil'";
            $result = mysqli_query($koneksi, $query);

            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>";
                        echo "<td class='cell'>" . safeDisplay($row['nama'] ?? '-') . "</td>";
                        echo "<td class='cell'>" . safeDisplay($row['nopol'] ?? '-') . "</td>";
                        echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_ambil'] ?? ''))) . "</td>";
                        echo "<td class='cell'>" . date('d M', strtotime(safeDisplay($row['tgl_kembali'] ?? ''))) . "</td>";
                        echo "<td class='cell'><span class='badge bg-info'>" . safeDisplay($row['status'] ?? '-') . "</span></td>";
                        echo "<td class='cell'><button class='btn-sm app-btn-secondary' data-toggle='modal' data-target='#kembaliModal' data-id='" . safeDisplay($row['id_transaksi'] ?? '-') . "' data-nopol='" . safeDisplay($row['nopol'] ?? '-') . "'>Kembali</button></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>Tidak ada data yang diambil</td></tr>";
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
            </div>
           

        </div>
    </div>

  <!-- Kembali Tab -->
<div class="tab-pane fade" id="transactions-kembali" role="tabpanel" aria-labelledby="transactions-kembali-tab">
    <div class="app-card app-card-transactions-table mb-5">
        <div class="app-card-body">
            <div class="table-responsive">
                <table class="table mb-0 text-left">
                    <thead>
                        <tr>
                            <th class="cell">Order</th>
                            <th class="cell">Customer</th>
                            <th class="cell">Mobil</th>
                            <th class="cell">Tanggal Bayar</th>
                            <th class="cell">Total Bayar</th>
                            <th class="cell">Status</th>
                            <th class="cell">Aksi</th> <!-- Tambahkan kolom aksi -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "
                        SELECT 
                            k.id_kembali, 
                            k.denda, 
                            b.tgl_bayar, 
                            b.total_bayar, 
                            b.status AS status_pelunasan, 
                            t.id_transaksi, 
                            m.nama AS customer, 
                            c.nopol AS mobil
                        FROM kembali k 
                        LEFT JOIN bayar b ON k.id_kembali = b.id_kembali COLLATE utf8mb4_general_ci
                        JOIN transaksi t ON k.id_transaksi = t.id_transaksi COLLATE utf8mb4_general_ci
                        JOIN member m ON t.nik = m.nik COLLATE utf8mb4_general_ci
                        JOIN mobil c ON t.nopol = c.nopol COLLATE utf8mb4_general_ci
                    ";
                    

                        $result = mysqli_query($koneksi, $query);

                        if ($result) {
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>"; // Tampilkan ID Transaksi
                                    echo "<td class='cell'>" . safeDisplay($row['customer'] ?? '-') . "</td>"; // Tampilkan Nama Customer
                                    echo "<td class='cell'>" . safeDisplay($row['mobil'] ?? '-') . "</td>"; // Tampilkan Nomor Polisi Mobil
                                    echo "<td class='cell'>" . (isset($row['tgl_bayar']) ? date('d M Y', strtotime(safeDisplay($row['tgl_bayar']))) : '-') . "</td>";
                                    echo "<td class='cell'>" . (isset($row['total_bayar']) ? safeDisplay($row['total_bayar']) : '-') . "</td>";
                                    
                                    // Tampilkan status pelunasan
                                    if (isset($row['status_pelunasan']) && $row['status_pelunasan'] === 'lunas') {
                                        echo "<td class='cell'><span class='badge bg-success'>Lunas</span></td>";
                                    } else {
                                        echo "<td class='cell'><span class='badge bg-danger'>Belum Lunas</span></td>";
                                    }
                                    
                                    // Tambahkan tombol untuk konfirmasi pelunasan
                                    echo "<td class='cell'>";
                                    if (!isset($row['status_pelunasan']) || $row['status_pelunasan'] !== 'lunas') {
                                        echo "<button class='btn btn-primary' data-toggle='modal' data-target='#modalPelunasan' 
      data-id='" . safeDisplay($row['id_kembali'] ?? '-') . "' 
      data-denda='" . safeDisplay($row['denda'] ?? '0.00') . "' 
      data-idtransaksi='" . safeDisplay($row['id_transaksi'] ?? '-') . "' 
      data-customer='" . safeDisplay($row['customer'] ?? '-') . "' 
      data-mobil='" . safeDisplay($row['mobil'] ?? '-') . "' 
      data-kekurangan='" . safeDisplay($row['kekurangan'] ?? '0.00') . "'>Konfirmasi</button>";

                                    } else {
                                        echo "-";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data pelunasan</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Kembali Tab -->
<div class="tab-pane fade" id="transactions-kembali" role="tabpanel" aria-labelledby="transactions-kembali-tab">
    <div class="app-card app-card-transactions-table shadow-sm mb-5">
            <div class="app-card-body">
                <div class="table-responsive">
                <table class="table mb-0 text-left">
                    <thead>
                        <tr>
                            <th class="cell">Order</th>
                            <th class="cell">Customer</th>
                            <th class="cell">Mobil</th>
                            <th class="cell">Tanggal Bayar</th>
                            <th class="cell">Total Bayar</th>
                            <th class="cell">Status</th>
                            <th class="cell">Aksi</th> <!-- Tambahkan kolom aksi -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "
                        SELECT 
                            k.id_kembali, 
                            k.denda, 
                            b.tgl_bayar, 
                            b.total_bayar, 
                            b.status AS status_pelunasan, 
                            t.id_transaksi, 
                            t.kekurangan, 
                            m.nama AS customer, 
                            c.nopol AS mobil
                        FROM kembali k 
                        LEFT JOIN bayar b ON k.id_kembali = b.id_kembali COLLATE utf8mb4_general_ci
                        JOIN transaksi t ON k.id_transaksi = t.id_transaksi COLLATE utf8mb4_general_ci
                        JOIN member m ON t.nik = m.nik COLLATE utf8mb4_general_ci
                        JOIN mobil c ON t.nopol = c.nopol COLLATE utf8mb4_general_ci
                    ";
                    
                        $result = mysqli_query($koneksi, $query);

                        if ($result) {
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td class='cell'>#" . safeDisplay($row['id_transaksi'] ?? '-') . "</td>"; // Tampilkan ID Transaksi
                                    echo "<td class='cell'>" . safeDisplay($row['customer'] ?? '-') . "</td>"; // Tampilkan Nama Customer
                                    echo "<td class='cell'>" . safeDisplay($row['mobil'] ?? '-') . "</td>"; // Tampilkan Nomor Polisi Mobil
                                    echo "<td class='cell'>" . (isset($row['tgl_bayar']) ? date('d M Y', strtotime(safeDisplay($row['tgl_bayar']))) : '-') . "</td>";
                                    echo "<td class='cell'>" . (isset($row['total_bayar']) ? safeDisplay($row['total_bayar']) : '-') . "</td>";
                                    
                                    // Tampilkan status pelunasan
                                    if (isset($row['status_pelunasan']) && $row['status_pelunasan'] === 'lunas') {
                                        echo "<td class='cell'><span class='badge bg-success'>Lunas</span></td>";
                                    } else {
                                        echo "<td class='cell'><span class='badge bg-danger'>Belum Lunas</span></td>";
                                    }
                                    
                                    // Tambahkan tombol untuk konfirmasi pelunasan
                                    echo "<td class='cell'>";
                                    if (!isset($row['status_pelunasan']) || $row['status_pelunasan'] !== 'lunas') {
                                        echo "<button class='btn btn-primary' data-toggle='modal' data-target='#modalPelunasan' 
      data-id='" . safeDisplay($row['id_kembali'] ?? '-') . "' 
      data-denda='" . safeDisplay($row['denda'] ?? '0.00') . "' 
      data-idtransaksi='" . safeDisplay($row['id_transaksi'] ?? '-') . "' 
      data-customer='" . safeDisplay($row['customer'] ?? '-') . "' 
      data-mobil='" . safeDisplay($row['mobil'] ?? '-') . "' 
      data-kekurangan='" . safeDisplay($row['kekurangan'] ?? '0.00') . "'>Konfirmasi</button>";

                                    } else {
                                        echo "-";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center'>Tidak ada data pelunasan</td></tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>Query gagal: " . mysqli_error($koneksi) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!-- Modal untuk Konfirmasi Pelunasan -->
<div class="modal fade" id="modalPelunasan" tabindex="-1" role="dialog" aria-labelledby="modalPelunasanLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalPelunasanLabel">Konfirmasi Pelunasan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formPelunasan" method="post" action="proses_pelunasan.php">
                    <input type="hidden" name="id_kembali" id="id_kembali" value="">
                    <input type="hidden" name="id_transaksi" id="id_transaksi" value="">
                    <div class="form-group">
                        <label for="customer">Customer</label>
                        <input type="text" class="form-control" id="customer" name="customer" readonly>
                    </div>
                    <div class="form-group">
                        <label for="mobil">Mobil</label>
                        <input type="text" class="form-control" id="mobil" name="mobil" readonly>
                    </div>
                    <div class="form-group">
                        <label for="total_bayar">Total Bayar (Denda + Biaya Sewa)</label>
                        <input type="text" class="form-control" id="total_bayar" name="total_bayar" readonly>
                    </div>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $('#modalPelunasan').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Tombol yang diklik
    var idKembali = button.data('id'); // Ambil data id_kembali dari tombol
    var denda = parseFloat(button.data('denda')); // Ambil data denda dari tombol dan pastikan sebagai float
    var idTransaksi = button.data('idtransaksi'); // Ambil data id_transaksi dari tombol
    var customer = button.data('customer'); // Ambil data customer dari tombol
    var mobil = button.data('mobil'); // Ambil data mobil dari tombol
    var kekurangan = parseFloat(button.data('kekurangan')); // Ambil data kekurangan dari tombol

    var modal = $(this);
    modal.find('#id_kembali').val(idKembali);
    modal.find('#id_transaksi').val(idTransaksi);
    modal.find('#customer').val(customer); // Isi nama customer
    modal.find('#mobil').val(mobil); // Isi nomor polisi mobil

    // Hitung total bayar (kekurangan + denda)
    var totalBayar = kekurangan + denda;
    modal.find('#total_bayar').val(totalBayar.toFixed(2)); // Format total bayar dengan 2 decimal
});

</script>

 <!-- Modal untuk Kembali -->
<div class="modal fade" id="kembaliModal" tabindex="-1" role="dialog" aria-labelledby="kembaliModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="kembaliModalLabel">Kembalikan Mobil</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="kembali.php" method="POST">
                    <input type="hidden" name="id_transaksi" id="modalIdTransaksi">
                    <div class="form-group">
                        <label for="kondisi_mobil">Kondisi Mobil</label>
                        <textarea class="form-control" id="kondisi_mobil" name="kondisi_mobil" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="denda">Denda</label>
                        <input type="number" class="form-control" id="denda" name="denda" value="0" min="0">
                    </div>
                    <button type="submit" class="btn btn-primary">Kembalikan</button>
                </form>
            </div>
        </div>
    </div>
</div>




<script>
    // Script untuk mengisi modal dengan data dari tombol Kembali
    $('#kembaliModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Tombol yang memicu modal
        var idTransaksi = button.data('id'); // Ambil data-id
        var mobil = button.data('mobil'); // Ambil data-mobil

        var modal = $(this);
        modal.find('#modalIdTransaksi').val(idTransaksi); // Isi id_transaksi di modal
        modal.find('#mobil').text(mobil); // Tampilkan nopol di modal jika diperlukan
    });
</script>


	    </div><!--//app-content-->
	    
	    <footer class="app-footer">
		    <div class="container text-center py-3">
		         <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
            <small class="copyright">Designed with <span class="sr-only">love</span><svg class="svg-inline--fa fa-heart" style="color: #fb866a;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z"></path></svg><!-- <i class="fas fa-heart" style="color: #fb866a;"></i> Font Awesome fontawesome.com --> by <a class="app-link" href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
		       
		    </div>
	    </footer><!--//app-footer-->
	    
    </div>


	<style>
    .custom-alert {
        display: none; /* Sembunyikan alert secara default */
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #28a745; /* Warna hijau untuk notifikasi berhasil */
        color: white;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 9999;
    }

    .alert-text {
        font-size: 16px;
        font-weight: bold;
    }
</style> 					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script>
    <!-- Memuat CSS Bootstrap -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Memuat jQuery dan JS Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

 


<script>
    $(document).ready(function() {
        $('#kembaliModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget); // Tombol yang memicu modal
            var id_transaksi = button.data('id'); // Ambil data-id dari tombol
            var mobil = button.data('mobil'); // Ambil data-mobil dari tombol

            // Isi input hidden dengan id_transaksi
            var modal = $(this);
            modal.find('#modalIdTransaksi').val(id_transaksi);
        });
    });

  

</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>




<div id="customAlert" class="custom-alert">
    <span class="alert-text">Mobil Berhasil Ditambahkan!</span>
</div>

<div id="customAlert2" class="custom-alert">
    <span class="alert-text"> Data Berhasil Diperbarui!</span>
</div>
<script src="path/to/your/js/bootstrap.bundle.min.js"></script>






</body>
</html> 