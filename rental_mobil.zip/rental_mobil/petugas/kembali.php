<?php
include "koneksi.php"; // Koneksi ke database
session_start(); // Memulai session

// Cek apakah pengguna sudah login dan memiliki akses
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
    exit();
}

// Cek apakah ada data yang dikirim melalui POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil dan bersihkan data dari form
    $id_transaksi = $_POST['id_transaksi'] ?? null;
    $kondisi_mobil = $_POST['kondisi_mobil'] ?? '';
    $late_days = $_POST['late_days'] ?? 0; // Ambil jumlah hari keterlambatan
    $denda_kondisi = $_POST['denda_kondisi'] ?? 0; // Ambil denda kerusakan

    // Validasi input
    if (empty($id_transaksi)) {
        die("ID transaksi tidak boleh kosong.");
    }

    // Hitung total denda
    $dendaPerHari = 600000; // Denda per hari
    $additional_fine = $late_days * $dendaPerHari; // Hitung denda keterlambatan
    $total_denda = $additional_fine + $denda_kondisi; // Total denda

    // Persiapkan query untuk menyimpan data pengembalian
    $query_kembali = "INSERT INTO kembali (id_transaksi, tgl_kembali, kondisi_mobil, denda) VALUES (?, NOW(), ?, ?)";

    // Menyiapkan statement
    if ($stmt = mysqli_prepare($koneksi, $query_kembali)) {
        // Mengikat parameter
        mysqli_stmt_bind_param($stmt, 'isd', $id_transaksi, $kondisi_mobil, $total_denda);

        // Eksekusi statement
        if (mysqli_stmt_execute($stmt)) {
            // Ambil ID yang baru saja dimasukkan
            $id_kembali = mysqli_insert_id($koneksi);

            // Update status transaksi menjadi 'kembali'
            $query_update = "UPDATE transaksi SET status='kembali' WHERE id_transaksi=?";
            if ($stmt_update = mysqli_prepare($koneksi, $query_update)) {
                mysqli_stmt_bind_param($stmt_update, 'i', $id_transaksi);
                mysqli_stmt_execute($stmt_update);
                mysqli_stmt_close($stmt_update);
            }

            // Jika berhasil, arahkan kembali ke halaman yang sesuai dengan pesan sukses
            header("Location: coba1.php?message=Pengembalian berhasil. ID Kembali: $id_kembali");
            exit();
        } else {
            // Jika gagal, tampilkan pesan error
            echo "Error saat menyimpan data pengembalian: " . mysqli_error($koneksi);
        }

        // Tutup statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Error dalam persiapan query: " . mysqli_error($koneksi);
    }
} else {
    echo "Tidak ada data yang diterima.";
}

// Tutup koneksi
mysqli_close($koneksi);
?>
