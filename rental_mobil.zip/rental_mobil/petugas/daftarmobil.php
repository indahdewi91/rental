<?php
    include "koneksi.php"; // Koneksi ke database
    session_start(); // Memulai session
    
    // Cek apakah pengguna sudah login
    if (!isset($_SESSION['id_user'])) {
        header("Location: ../login.php"); // Arahkan ke halaman login jika tidak memiliki akses
        exit();
    }

    
    

?>


<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Rentall Digital</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="img/.png"> 
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

    <!-- Include CSS Bootstrap -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- Include JS Bootstrap -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>

.table {
            width: 100%; /* Memastikan tabel menggunakan 100% lebar kontainer */
            table-layout: fixed; /* Mengatur tata letak tetap */
            overflow: hidden; /* Menghindari overflow */
        }

        .table th, .table td {
            word-wrap: break-word; /* Memungkinkan pemotongan kata yang panjang */
            text-overflow: ellipsis; /* Menambahkan ellipsis jika teks terlalu panjang */
            overflow: hidden; /* Menghindari overflow pada sel */
        }

        .table img {
            max-width: 80px; /* Membatasi lebar gambar */
            height: auto; /* Mempertahankan rasio aspek gambar */
        }

        @media (max-width: 768px) {
            .table th, .table td {
                padding: 8px; /* Mengurangi padding pada perangkat kecil */
                font-size: 14px; /* Mengurangi ukuran font */
            }
            
            .table {
                font-size: 12px; /* Ukuran font lebih kecil untuk tampilan yang lebih baik */
            }
        }
        
    .pagination .page-link {
    color: #5CB377; /* Warna teks */
}

.pagination .page-link:hover {
    background-color: #5CB377; /* Warna background saat hover */
    color: white; /* Warna teks saat hover */
}

.pagination .page-item.active .page-link {
    background-color: #5CB377; /* Warna background halaman aktif */
    border-color: #5CB377; /* Warna border halaman aktif */
    color: white; /* Warna teks halaman aktif */
}

.pagination .page-item.disabled .page-link {
    color: #d3d3d3; /* Warna teks untuk tombol yang disabled */
}

    .btn-outline-primary:hover {
        background-color: #5CB377; 
        color: white; 
    }

    .btn-outline-primary {
    --bs-btn-color: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #FFFF;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 21, 163, 98;
    --bs-btn-active-color: #FFFF;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #5cb377;
    --bs-btn-disabled-bg: transparent;
    --bs-gradient: none;
    }

	.btn-info {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5cb377;
    --bs-btn-border-color: #5cb377;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5cb377;
    --bs-btn-hover-border-color: #5cb377;
    --bs-btn-focus-shadow-rgb: 77, 130, 199;
    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: #5cb377;
    --bs-btn-active-border-color: #5cb377;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #5cb377;
    --bs-btn-disabled-border-color: #5cb377;
}

.btn-primary {
    --bs-btn-color: #ffff;
    --bs-btn-bg: #5b99ea ;
    --bs-btn-border-color: #5b99ea ;
    --bs-btn-hover-color: #ffff;
    --bs-btn-hover-bg: #5b99ea;
    --bs-btn-hover-border-color: #5b99ea;
    --bs-btn-focus-shadow-rgb: 18, 139, 83;
    --bs-btn-active-color: #ffff;
    --bs-btn-active-bg: #44b581;
    --bs-btn-active-border-color: #2cac72;
    --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
    --bs-btn-disabled-color: #ffff;
    --bs-btn-disabled-bg: #15a362;
    --bs-btn-disabled-border-color: #15a362;
}
</style>

</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <svg class="svg-inline--fa fa-magnifying-glass search-mobile-trigger-icon" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M500.3 443.7l-119.7-119.7c27.22-40.41 40.65-90.9 33.46-144.7C401.8 87.79 326.8 13.32 235.2 1.723C99.01-15.51-15.51 99.01 1.724 235.2c11.6 91.64 86.08 166.7 177.6 178.9c53.8 7.189 104.3-6.236 144.7-33.46l119.7 119.7c15.62 15.62 40.95 15.62 56.57 0C515.9 484.7 515.9 459.3 500.3 443.7zM79.1 208c0-70.58 57.42-128 128-128s128 57.42 128 128c0 70.58-57.42 128-128 128S79.1 278.6 79.1 208z"></path></svg><!-- <i class="search-mobile-trigger-icon fas fa-search"></i> Font Awesome fontawesome.com -->
			        </div><!--//col-->
		            
		            <div class="app-utilities col-auto">
			            
			            
			            <div class="app-utility-item app-user-dropdown dropdown">
                        <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><img src="assets/images/user.png" alt="user profile"></a>
				            <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="../logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel sidepanel-hidden"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">×</a>
		        <div class="app-branding">
                <a class="app-logo" href="index.php"><span class="logo-text">Rentall</span></a>
	
		        </div><!--//app-branding-->  
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
                <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="coba1.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-card-list" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
  <path fill-rule="evenodd" d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5z"/>
  <circle cx="3.5" cy="5.5" r=".5"/>
  <circle cx="3.5" cy="8" r=".5"/>
  <circle cx="3.5" cy="10.5" r=".5"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="daftarmobil.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-car-front" viewBox="0 0 16 16">
  <path d="M4 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0m10 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0M6 8a1 1 0 0 0 0 2h4a1 1 0 1 0 0-2zM4.862 4.276 3.906 6.19a.51.51 0 0 0 .497.731c.91-.073 2.35-.17 3.597-.17s2.688.097 3.597.17a.51.51 0 0 0 .497-.731l-.956-1.913A.5.5 0 0 0 10.691 4H5.309a.5.5 0 0 0-.447.276"/>
  <path d="M2.52 3.515A2.5 2.5 0 0 1 4.82 2h6.362c1 0 1.904.596 2.298 1.515l.792 1.848c.075.175.21.319.38.404.5.25.855.715.965 1.262l.335 1.679q.05.242.049.49v.413c0 .814-.39 1.543-1 1.997V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.338c-1.292.048-2.745.088-4 .088s-2.708-.04-4-.088V13.5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1.892c-.61-.454-1-1.183-1-1.997v-.413a2.5 2.5 0 0 1 .049-.49l.335-1.68c.11-.546.465-1.012.964-1.261a.8.8 0 0 0 .381-.404l.792-1.848ZM4.82 3a1.5 1.5 0 0 0-1.379.91l-.792 1.847a1.8 1.8 0 0 1-.853.904.8.8 0 0 0-.43.564L1.03 8.904a1.5 1.5 0 0 0-.03.294v.413c0 .796.62 1.448 1.408 1.484 1.555.07 3.786.155 5.592.155s4.037-.084 5.592-.155A1.48 1.48 0 0 0 15 9.611v-.413q0-.148-.03-.294l-.335-1.68a.8.8 0 0 0-.43-.563 1.8 1.8 0 0 1-.853-.904l-.792-1.848A1.5 1.5 0 0 0 11.18 3z"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Kelola Koleksi</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="daftaruser.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M10 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zM8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm6 5c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"></path>
</svg>
						         </span>
		                         <span class="nav-link-text">Daftar Member</span>
					        </a><!--//nav-link-->
					    </li>
                        <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="laporan.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-receipt" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.92.506a.5.5 0 0 1 .434.14L3 1.293l.646-.647a.5.5 0 0 1 .708 0L5 1.293l.646-.647a.5.5 0 0 1 .708 0L7 1.293l.646-.647a.5.5 0 0 1 .708 0L9 1.293l.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .801.13l.5 1A.5.5 0 0 1 15 2v12a.5.5 0 0 1-.053.224l-.5 1a.5.5 0 0 1-.8.13L13 14.707l-.646.647a.5.5 0 0 1-.708 0L11 14.707l-.646.647a.5.5 0 0 1-.708 0L9 14.707l-.646.647a.5.5 0 0 1-.708 0L7 14.707l-.646.647a.5.5 0 0 1-.708 0L5 14.707l-.646.647a.5.5 0 0 1-.708 0L3 14.707l-.646.647a.5.5 0 0 1-.801-.13l-.5-1A.5.5 0 0 1 1 14V2a.5.5 0 0 1 .053-.224l.5-1a.5.5 0 0 1 .367-.27zm.217 1.338L2 2.118v11.764l.137.274.51-.51a.5.5 0 0 1 .707 0l.646.647.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.646.646.646-.646a.5.5 0 0 1 .708 0l.509.509.137-.274V2.118l-.137-.274-.51.51a.5.5 0 0 1-.707 0L12 1.707l-.646.647a.5.5 0 0 1-.708 0L10 1.707l-.646.647a.5.5 0 0 1-.708 0L8 1.707l-.646.647a.5.5 0 0 1-.708 0L6 1.707l-.646.647a.5.5 0 0 1-.708 0L4 1.707l-.646.647a.5.5 0 0 1-.708 0l-.509-.51z"></path>
	  <path fill-rule="evenodd" d="M3 4.5a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 1 1 0 1h-6a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5zm8-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z"></path>
	</svg>
						         </span>
		                         <span class="nav-link-text">Laporan</span>
					        </a><!--//nav-link-->
					    </li>

						
				    </ul><!--//app-menu-->
			    </nav><!--//app-nav-->
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->
    
    <div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
		    <!--//container-fluid-->
            <div class="container-xl">
			<h1 class="app-page-title">Daftar Mobil</h1>
			<div class="app-card shadow-sm mb-4 border-left-decoration">
				    <div class="inner">
					    <div class="app-card-body p-4">
						    <div class="row gx-5 gy-3">
						        <div class="col-12 col-lg-9">
							        
							        <div>Daftar mobil yang tersedia.</div>
							    </div><!--//col-->
							    <div class="col-12 col-lg-3">
    <button class="btn app-btn-primary" data-bs-toggle="modal" data-bs-target="#tambahMobilModal">
        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-download me-1" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"></path>
            <path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
        </svg>Tambah Koleksi
    </button>
</div>

						    </div><!--//row-->
	
					    </div><!--//app-card-body-->
					    
				    </div><!--//inner-->
			    </div>
  <div class="mb-3">
                <input type="text" id="search" class="form-control" placeholder="Cari mobil...">
    </div>

    <!-- Daftar mobil -->
<div class="tab-content" id="orders-table-tab-content">
    <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
        <div class="app-card app-card-orders-table shadow-sm mb-5">
            <div class="app-card-body">
                <div class="table-responsive">
                    <div style="overflow-x:auto;">
                        <table class="table app-table-hover mb-0 text-left">
                            <thead>
                                <tr align="center">
                                    <th class="cell" style="width: 10%;">Nomor Polisi</th>
                                    <th class="cell" style="width: 15%;">Gambar</th>
                                    <th class="cell" style="width: 20%;">Brand</th>
                                    <th class="cell" style="width: 15%;">Tipe</th>
                                    <th class="cell" style="width: 10%;">Tahun</th>
                                    <th class="cell" style="width: 15%;">Harga Sewa</th>
                                    <th class="cell" style="width: 10%;">Status</th>
                                    <th class="cell" style="width: 10%;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="resultsTableBody">
                                <?php

                                // Query untuk mengambil data mobil
                                $query = "SELECT * FROM mobil";
                                $result = mysqli_query($koneksi, $query);
                                
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $imageFileName = $row['foto']; // Mengambil nama file gambar dari database
                                ?>
                                    <tr class="book-item" align="center">
                                        <td class="cell"><?php echo $row['nopol']; ?></td>
                                        <td class="cell">
                                            <?php if (!empty($imageFileName)): ?>
                                                <img src="../img/<?php echo $imageFileName; ?>" alt="Gambar Mobil">
                                            <?php else: ?>
                                                Tidak Ada Gambar
                                            <?php endif; ?>
                                        </td>
                                        <td class="cell"><?php echo $row['brand']; ?></td>
                                        <td class="cell"><?php echo $row['type']; ?></td>
                                        <td class="cell"><?php echo $row['tahun']; ?></td>
                                        <td class="cell"><?php echo number_format($row['harga'], 2, ',', '.'); ?> IDR</td>
                                        <td class="cell"><?php echo ucfirst($row['status']); ?></td>
                                        <td class="cell" align="center">
                                            <a href="#" onclick="showEditModal('<?php echo $row['nopol']; ?>');">
                                                <button name="edit" class="btn btn-warning" style="color: white"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
</svg></button>
                                            </a>
                                            <a href="#" onclick="showDeleteModal('<?php echo $row['nopol']; ?>');">
                                                <button class="btn btn-danger" style="color: white"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
  <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
</svg></button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                
</div>







						        </div><!--//table-responsive-->

								<div class="modal fade" id="hapusModal" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusModalLabel">Rentaol</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Anda yakin ingin menghapus koleksi ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"  style="color: white">Batal</button>
                <a id="confirmDelete" href="#" class="btn btn-danger" style="color: white">Hapus</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal Input Mobil -->
<div class="modal fade" id="tambahMobilModal" tabindex="-1" aria-labelledby="tambahMobilModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahMobilModalLabel">Tambah Mobil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="" method="POST" class="settings-form" enctype="multipart/form-data">
    <div class="mb-3">
        <label for="setting-input-1" class="form-label">Nomor Polisi</label>
        <input type="text" class="form-control" id="setting-input-1" placeholder="Nomor Polisi" required name="nopol">
    </div>
    <div class="mb-3">
        <label for="setting-input-2" class="form-label">Brand</label>
        <input type="text" class="form-control" id="setting-input-2" placeholder="Brand" required name="brand">
    </div>
    <div class="mb-3">
        <label for="setting-input-3" class="form-label">Tipe Mobil</label>
        <input type="text" class="form-control" id="setting-input-3" placeholder="Tipe" required name="type">
    </div>
    <div class="mb-3">
        <label for="setting-input-4" class="form-label">Tahun</label>
        <input type="text" class="form-control" id="setting-input-4" placeholder="Tahun" required name="tahun">
    </div>
    <div class="mb-3">
        <label for="setting-input-6" class="form-label">Harga Sewa</label>
        <input type="text" class="form-control" id="setting-input-6" placeholder="Harga Sewa" required name="harga">
    </div>
    <div class="mb-3">
        <label for="foto" class="form-label">Gambar</label>
        <input class="form-control" id="foto" type="file" accept="image/png, image/gif, image/jpeg" name="foto" required>
    </div>
    <input type="hidden" class="form-control" id="status" name="hidden" >
    <button type="submit" name="submit" value="submit" class="btn app-btn-primary">Simpan</button>
</form>

<?php
if (isset($_POST['submit'])) {
    // Mengambil data dari form
    $nopol = $_POST['nopol'];
    $brand = $_POST['brand'];
    $type = $_POST['type'];
    $tahun = $_POST['tahun'];
    $harga = $_POST['harga'];


    $foto = $_FILES['foto']['name']; // Ambil nama file gambar dari input

    // Memastikan nama file valid
    if (!empty($foto)) {
        // Menyimpan data ke database
        $sql = "INSERT INTO `mobil` (`nopol`, `brand`, `type`, `tahun`, `harga`, `foto`, `status`) 
                VALUES ('$nopol', '$brand', '$type', '$tahun', '$harga', '$foto', 'tersedia');";

        $query = mysqli_query($koneksi, $sql);
            

            if ($query) {
                echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    var customAlert = document.getElementById('customAlert');
                    customAlert.style.display = 'block';

                    setTimeout(function() {
                        window.location.href = 'daftarmobil.php'; // Redirect ke daftar mobil
                    }, 2000);
                });
                </script>";
            } else {
                echo "Terjadi kesalahan saat menambahkan mobil: " . mysqli_error($koneksi);
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "";
    }
?>


            </div>
        </div>
    </div>
</div>



<!-- Modal Edit Mobil -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="" method="POST" class="settings-form" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Mobil</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit-nopol" class="form-label">No. Polisi</label>
                        <input type="text" class="form-control" id="edit-nopol" name="nopol" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="edit-brand" class="form-label">Brand</label>
                        <input type="text" class="form-control" id="edit-brand" name="brand">
                    </div>
                    <div class="mb-3">
                        <label for="edit-type" class="form-label">Tipe</label>
                        <input type="text" class="form-control" id="edit-type" name="type">
                    </div>
                    <div class="mb-3">
                        <label for="edit-tahun" class="form-label">Tahun</label>
                        <input type="text" class="form-control" id="edit-tahun" name="tahun">
                    </div>
                    <div class="mb-3">
                        <label for="edit-harga" class="form-label">Harga Sewa</label>
                        <input type="number" class="form-control" id="edit-harga" name="harga" step="0.01">
                    </div>
                    <div class="mb-3">
                        <label for="edit-status" class="form-label">Status</label>
                        <select class="form-select" id="edit-status" name="status">
                            <option value="tersedia">Tersedia</option>
                            <option value="tidak">Tidak Tersedia</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit-img_file" class="form-label">Upload Gambar Baru</label>
                        <input type="file" class="form-control" id="edit-img_file" name="img_file">
                        <small class="form-text text-muted">Kosongkan jika tidak ingin mengganti gambar.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" name="submit" value="submit" class="btn btn-primary" style="color: white">Simpan</button>
                </div>
            </form>

            <?php
            if (isset($_POST['submit'])) {
                include 'koneksi.php';

                $nopol = $_POST['nopol'];
                $brand = $_POST['brand'];
                $type = $_POST['type'];
                $tahun = $_POST['tahun'];
                $harga = $_POST['harga'];
                $status = $_POST['status'];

                // Mengatur gambar jika ada file yang diupload
                if (isset($_FILES['img_file']) && $_FILES['img_file']['error'] == 0) {
                    $target_dir = "img/"; 
                    $target_file = $target_dir . basename($_FILES["img_file"]["name"]);
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                    // Memeriksa apakah file adalah gambar
                    if (getimagesize($_FILES["img_file"]["tmp_name"]) === false) {
                        echo "File bukan gambar.";
                        $uploadOk = 0;
                    }

                    // Memeriksa ukuran file
                    if ($_FILES["img_file"]["size"] > 5000000) { 
                        echo "Ukuran file terlalu besar.";
                        $uploadOk = 0;
                    }

                    // Memeriksa tipe file
                    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                        echo "Hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.";
                        $uploadOk = 0;
                    }

                    // Upload file jika semua pengecekan lolos
                    if ($uploadOk == 1) {
                        if (move_uploaded_file($_FILES["img_file"]["tmp_name"], $target_file)) {
                            $img = basename($_FILES["img_file"]["name"]); 
                        } else {
                            echo "Terjadi kesalahan saat meng-upload gambar.";
                        }
                    }
                }

                // Update data mobil
                $sql = "UPDATE mobil SET brand = '$brand', type = '$type', tahun = '$tahun', harga = '$harga', status = '$status' WHERE nopol = '$nopol'";
                $query = mysqli_query($koneksi, $sql);

                if ($query) {
                    echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        var customAlert2 = document.getElementById('customAlert2');
                        customAlert2.style.display = 'block';
                        setTimeout(function() {
                            window.location.href = 'daftarmobil.php';
                        },500);
                    });
                    </script>";
                } else {
                    echo "<script>alert('Gagal memperbarui data mobil.');</script>";
                }
            }
            ?>
        </div>
    </div>
</div>

<script>
function showEditModal(nopol) {
    // Mengambil data mobil dari server (misalnya, dengan AJAX)
    fetch(`get_mobil.php?nopol=${nopol}`)
        .then(response => response.json())
        .then(data => {
            // Mengisi field di dalam modal dengan data mobil
            document.getElementById('edit-nopol').value = data.nopol;
            document.getElementById('edit-brand').value = data.brand;
            document.getElementById('edit-type').value = data.type;
            document.getElementById('edit-tahun').value = data.tahun;
            document.getElementById('edit-harga').value = data.harga;
            document.getElementById('edit-status').value = data.status;

            // Menampilkan modal
            var editModal = new bootstrap.Modal(document.getElementById('editModal'));
            editModal.show();
        })
        .catch(error => console.error('Error:', error));
}
</script>


<div class="modal fade" id="hapusModal" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="hapusModalLabel">Rentall</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Anda yakin ingin menghapus buku ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"  style="color: white">Batal</button>
                <a id="confirmDelete" href="#" class="btn btn-danger" style="color: white">Hapus</a>
            </div>
        </div>
    </div>
</div>






						       
						    </div><!--//app-card-body-->		
						</div><!--//app-card-->
					
						
			        </div><!--//tab-pane-->
			        
			    
				</div><!--//tab-content-->
	    </div><!--//app-content-->
	    
	    <footer class="app-footer">
		    <div class="container text-center py-3">
		         <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
            <small class="copyright">Designed with <span class="sr-only">love</span><svg class="svg-inline--fa fa-heart" style="color: #fb866a;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z"></path></svg><!-- <i class="fas fa-heart" style="color: #fb866a;"></i> Font Awesome fontawesome.com --> by <a class="app-link" href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
		       
		    </div>
	    </footer><!--//app-footer-->
	    
    </div><!--//app-wrapper-->   
	<style>
    .custom-alert {
        display: none; /* Sembunyikan alert secara default */
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #28a745; /* Warna hijau untuk notifikasi berhasil */
        color: white;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 9999;
    }

    .alert-text {
        font-size: 16px;
        font-weight: bold;
    }
</style> 					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 

	<script>
	function showDeleteModal(nopol) {
        document.getElementById('confirmDelete').setAttribute('href', 'hapus.php?nopol=' + nopol);
        var myModal = new bootstrap.Modal(document.getElementById('hapusModal'));
        myModal.show();
    }

    
</script>

<script>
    // Ambil elemen input dan tabel
    const searchInput = document.getElementById('search');
    const resultsTableBody = document.getElementById('resultsTableBody');

    // Tambahkan event listener ke input pencarian
    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();
        const rows = resultsTableBody.getElementsByTagName('tr');

        // Loop melalui semua baris dan sembunyikan yang tidak sesuai dengan pencarian
        for (let i = 0; i < rows.length; i++) {
            const nopol = rows[i].getElementsByTagName('td')[0]; // Kolom Nomor Polisi
            const brand = rows[i].getElementsByTagName('td')[2]; // Kolom Brand
            const type = rows[i].getElementsByTagName('td')[3];  // Kolom Tipe

            // Cek apakah data yang dicari cocok dengan input
            if (nopol || brand || type) {
                const nopolText = nopol.textContent.toLowerCase();
                const brandText = brand.textContent.toLowerCase();
                const typeText = type.textContent.toLowerCase();

                if (nopolText.includes(filter) || brandText.includes(filter) || typeText.includes(filter)) {
                    rows[i].style.display = ""; // Tampilkan baris jika cocok
                } else {
                    rows[i].style.display = "none"; // Sembunyikan jika tidak cocok
                }
            }
        }
    });
</script>



<div id="customAlert" class="custom-alert">
    <span class="alert-text">Mobil Berhasil Ditambahkan!</span>
</div>

<div id="customAlert2" class="custom-alert">
    <span class="alert-text"> Data Berhasil Diperbarui!</span>
</div>
<script src="path/to/your/js/bootstrap.bundle.min.js"></script>
<!-- Include CSS Bootstrap -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- Include JS Bootstrap -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



</body>
</html> 