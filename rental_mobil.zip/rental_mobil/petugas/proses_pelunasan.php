// proses_pelunasan.php
<?php
include "koneksi.php"; // Koneksi ke database
session_start();

// Cek apakah pengguna sudah login dan memiliki akses
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php"); 
    exit();
}

// Ambil data dari form
$id_kembali = $_POST['id_kembali'];
$total_bayar = $_POST['total_bayar'];

// Insert ke tabel bayar
$query_bayar = "INSERT INTO bayar (id_kembali, tgl_bayar, total_bayar, status) VALUES ('$id_kembali', NOW(), '$total_bayar', 'lunas')";
mysqli_query($koneksi, $query_bayar);

// Update status pembayaran di tabel kembali
$query_update_kembali = "UPDATE kembali SET denda = CASE WHEN denda > 0 THEN denda ELSE 0 END WHERE id_kembali='$id_kembali'";
mysqli_query($koneksi, $query_update_kembali);

// Redirect ke halaman status peminjaman
header("Location: coba1.php?message=Pembayaran berhasil");
exit();
?>
