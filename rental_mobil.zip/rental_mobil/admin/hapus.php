<?php
include 'koneksi.php';

if (isset($_GET['nopol'])) {
    
    $nopol = $_GET['nopol'];

    $nopol = mysqli_real_escape_string($koneksi, $nopol);

    $sql = "DELETE FROM mobil WHERE nopol = '$nopol'";
    
    if (mysqli_query($koneksi, $sql)) {
        header("Location: daftarmobil.php"); 
        exit;
    } else {
        echo "Terjadi kesalahan saat menghapus data: " . mysqli_error($koneksi);
    }
}
?>
