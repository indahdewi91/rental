<?php
include 'koneksi.php';

$nopol = $_GET['nopol'];
$result = mysqli_query($koneksi, "SELECT * FROM mobil WHERE nopol = '$nopol'");
$data = mysqli_fetch_assoc($result);

echo json_encode($data);
?>
