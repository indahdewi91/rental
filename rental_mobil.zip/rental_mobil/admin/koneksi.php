<?php
    $koneksi = new mysqli('localhost','root','','rental_indah')
?>