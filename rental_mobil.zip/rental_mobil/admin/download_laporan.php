<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi Sewa Mobil</title>
    <style>
        /* CSS untuk tampilan cetak */
        @media print {
            @page {
                margin: 0; /* Hilangkan margin yang biasanya memunculkan URL di header/footer */
            }
            body {
                margin: 1cm; /* Tambahkan margin internal agar dokumen rapi */
            }

            /* Hilangkan elemen yang tidak diperlukan */
            .no-print {
                display: none;
            }
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid black;
            padding: 5px;
            text-align: center;
        }
    </style>
</head>
<body>

    <h2 align="center">Laporan Transaksi Sewa Mobil</h2>
    <table>
        <tr>
            <th>No</th>
            <th>Customer</th>
            <th>Mobil</th>
            <th>Tanggal Booking</th>
            <th>Total</th>
            <th>Status Pelunasan</th>
        </tr>
        <?php
        include "../koneksi.php"; // Pastikan ini mengarah ke file koneksi database
        $i = 1;
        $query = mysqli_query($koneksi, "
    SELECT 
        t.id_transaksi, 
        m.nama AS customer, 
        c.nopol AS mobil,
        t.tgl_booking,
        t.total,
        IF(b.status IS NULL, 'Belum Lunas', b.status) AS status_pelunasan
    FROM transaksi t 
    JOIN member m ON t.nik = m.nik 
    JOIN mobil c ON t.nopol = c.nopol
    LEFT JOIN kembali k ON t.id_transaksi = k.id_transaksi
    LEFT JOIN bayar b ON k.id_kembali = b.id_kembali
");


        // Periksa apakah query berhasil
        if (!$query) {
            die("Query Error: " . mysqli_error($koneksi));
        }

        // Tampilkan data
        while ($data = mysqli_fetch_array($query)) {
        ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo isset($data['customer']) ? $data['customer'] : 'N/A'; ?></td>
            <td><?php echo isset($data['mobil']) ? $data['mobil'] : 'N/A'; ?></td>
            <td><?php echo isset($data['tgl_booking']) ? date('d-m-Y', strtotime($data['tgl_booking'])) : 'N/A'; ?></td>
            <td><?php echo isset($data['total']) ? number_format($data['total'], 2, ',', '.') : '0.00'; ?></td>
            <td><?php echo isset($data['status_pelunasan']) ? $data['status_pelunasan'] : 'N/A'; ?></td>
        </tr>
        <?php
        }
        ?>
    </table>

    <button target="_blank" class="no-print" onclick="window.print()">Cetak Laporan</button> <!-- Tombol cetak -->
    <script>
        window.print();
        setTimeout(function() {
            window.close();
        }, 100);
    </script>

</body>
</html>
