<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Pastikan hashing sesuai kebutuhan

    // Query untuk memasukkan admin baru ke tabel user
    $query = "INSERT INTO user (username, password, role) VALUES ('$username', '$password', 'admin')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Admin berhasil ditambahkan!'); window.location.href='daftaruser.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan admin!'); window.location.href='daftaruser.php';</script>";
    }
}
?>
